"""
Unit tests for Multi-Agent Healthcare System
"""

import pytest
import asyncio
from datetime import datetime

from src.agents.base_agent import BaseAgent, AgentMessage, MessageType, AgentCapability
from src.agents.triage_agent import TriageAgent
from src.agents.knowledge_agent import KnowledgeAgent
from src.agents.response_agent import ResponseAgent
from src.agents.orchestrator import AgentOrchestrator
from src.security.privacy import DataAnonymizer, GDPRComplianceLogger
from src.fairness.bias_detection import FairnessMetrics, BiasDetector


class TestBaseAgent:
    """Tests for base agent functionality"""
    
    def test_agent_initialization(self):
        """Test agent can be initialized with correct properties"""
        agent = TriageAgent()
        
        assert agent.agent_id == "triage_agent"
        assert agent.name == "Triage Agent"
        assert AgentCapability.TRIAGE in agent.capabilities
        assert agent.performance_metrics["messages_sent"] == 0
    
    def test_send_message(self):
        """Test agent can send messages"""
        agent = TriageAgent()
        
        message = agent.send_message(
            receiver_id="knowledge_agent",
            content={"test": "data"},
            message_type=MessageType.REQUEST
        )
        
        assert message.sender_id == "triage_agent"
        assert message.receiver_id == "knowledge_agent"
        assert message.content["test"] == "data"
        assert agent.performance_metrics["messages_sent"] == 1
    
    def test_receive_message(self):
        """Test agent can receive messages"""
        agent = TriageAgent()
        
        message = AgentMessage(
            message_type=MessageType.REQUEST,
            sender_id="user",
            receiver_id="triage_agent",
            content={"query": "test"}
        )
        
        agent.receive_message(message)
        
        assert len(agent.message_queue) == 1
        assert agent.performance_metrics["messages_received"] == 1
    
    def test_state_management(self):
        """Test agent state management"""
        agent = TriageAgent()
        
        agent.update_state("test_key", "test_value")
        value = agent.get_state("test_key")
        
        assert value == "test_value"
    
    def test_capability_check(self):
        """Test agent capability checking"""
        agent = TriageAgent()
        
        assert agent.has_capability(AgentCapability.TRIAGE)
        assert not agent.has_capability(AgentCapability.KNOWLEDGE_RETRIEVAL)


class TestTriageAgent:
    """Tests for triage agent"""
    
    @pytest.mark.asyncio
    async def test_symptom_extraction(self):
        """Test symptom extraction from query"""
        agent = TriageAgent()
        
        result = await agent.execute_task({
            "query": "I have a headache, fever, and cough",
            "user_data": {}
        })
        
        assert "headache" in result["extracted_symptoms"]
        assert "fever" in result["extracted_symptoms"]
        assert "cough" in result["extracted_symptoms"]
        assert result["status"] == "triaged"
    
    @pytest.mark.asyncio
    async def test_urgency_determination_emergency(self):
        """Test emergency urgency detection"""
        agent = TriageAgent()
        
        result = await agent.execute_task({
            "query": "I'm having severe chest pain and difficulty breathing",
            "user_data": {}
        })
        
        assert result["urgency_level"] == "emergency"
    
    @pytest.mark.asyncio
    async def test_urgency_determination_low(self):
        """Test low urgency detection"""
        agent = TriageAgent()
        
        result = await agent.execute_task({
            "query": "I have a mild cough",
            "user_data": {}
        })
        
        assert result["urgency_level"] in ["low", "medium"]
    
    @pytest.mark.asyncio
    async def test_symptom_categorization(self):
        """Test symptom categorization"""
        agent = TriageAgent()
        
        result = await agent.execute_task({
            "query": "I have a cough, sore throat, and runny nose",
            "user_data": {}
        })
        
        categories = result["symptom_categories"]
        assert "respiratory" in categories


class TestKnowledgeAgent:
    """Tests for knowledge agent"""
    
    @pytest.mark.asyncio
    async def test_condition_matching(self):
        """Test condition matching from symptoms"""
        agent = KnowledgeAgent()
        
        result = await agent.execute_task({
            "extracted_symptoms": ["cough", "sore throat", "runny nose"],
            "symptom_categories": {"respiratory": ["cough", "sore throat"]},
            "urgency_level": "low"
        })
        
        assert result["knowledge_retrieved"]
        assert len(result["matched_conditions"]) > 0
        assert result["matched_conditions"][0]["condition_name"] in [
            "Common Cold", "Influenza (Flu)"
        ]
    
    @pytest.mark.asyncio
    async def test_confidence_scoring(self):
        """Test confidence scoring for matched conditions"""
        agent = KnowledgeAgent()
        
        result = await agent.execute_task({
            "extracted_symptoms": ["fever", "chills", "muscle ache", "cough"],
            "symptom_categories": {"respiratory": ["cough"]},
            "urgency_level": "medium"
        })
        
        # Should match influenza with high confidence
        matched = result["matched_conditions"]
        assert len(matched) > 0
        assert matched[0]["confidence_score"] > 0


class TestResponseAgent:
    """Tests for response agent"""
    
    @pytest.mark.asyncio
    async def test_response_generation(self):
        """Test response generation"""
        agent = ResponseAgent()
        
        result = await agent.execute_task({
            "extracted_symptoms": ["cough", "fever"],
            "urgency_level": "medium",
            "condition_details": [{
                "condition_name": "Influenza (Flu)",
                "confidence": 0.8,
                "typical_duration": "1-2 weeks",
                "self_care": ["Rest", "Fluids"],
                "when_to_seek_care": ["Difficulty breathing"],
                "severity": "medium"
            }],
            "general_advice": {
                "message": "Medical consultation advised",
                "actions": ["Schedule appointment"]
            }
        })
        
        assert result["response_generated"]
        assert "response_text" in result
        assert len(result["response_text"]) > 0
        assert "Influenza" in result["response_text"]
    
    @pytest.mark.asyncio
    async def test_emergency_response(self):
        """Test emergency response generation"""
        agent = ResponseAgent()
        
        result = await agent.execute_task({
            "extracted_symptoms": ["chest pain"],
            "urgency_level": "emergency",
            "general_advice": {
                "message": "SEEK IMMEDIATE MEDICAL ATTENTION",
                "actions": ["Call 911"]
            }
        })
        
        response = result["response_text"]
        assert "IMPORTANT" in response or "EMERGENCY" in response
        assert "911" in response


class TestOrchestrator:
    """Tests for agent orchestrator"""
    
    @pytest.mark.asyncio
    async def test_orchestrator_initialization(self):
        """Test orchestrator initializes agents"""
        orchestrator = AgentOrchestrator()
        
        assert len(orchestrator.agents) == 3
        assert "triage_agent" in orchestrator.agents
        assert "knowledge_agent" in orchestrator.agents
        assert "response_agent" in orchestrator.agents
    
    @pytest.mark.asyncio
    async def test_query_processing(self):
        """Test end-to-end query processing"""
        orchestrator = AgentOrchestrator()
        
        result = await orchestrator.process_user_query(
            query="I have a headache and fever",
            user_data={"age": 30}
        )
        
        assert result["status"] == "completed"
        assert "response_text" in result
        assert len(result["extracted_symptoms"]) > 0
    
    @pytest.mark.asyncio
    async def test_metrics_tracking(self):
        """Test metrics are tracked"""
        orchestrator = AgentOrchestrator()
        
        await orchestrator.process_user_query(
            query="I have a cough",
            user_data={}
        )
        
        metrics = orchestrator.get_metrics()
        assert metrics["total_conversations"] == 1
        assert metrics["successful_completions"] == 1


class TestDataAnonymizer:
    """Tests for data anonymization"""
    
    def test_email_anonymization(self):
        """Test email anonymization"""
        anonymizer = DataAnonymizer()
        
        result = anonymizer.anonymize_text(
            "Contact me at john@example.com"
        )
        
        assert "john@example.com" not in result["anonymized_text"]
        assert "email" in result["pii_detected"]
    
    def test_phone_anonymization(self):
        """Test phone number anonymization"""
        anonymizer = DataAnonymizer()
        
        result = anonymizer.anonymize_text(
            "Call me at 555-123-4567"
        )
        
        assert "555-123-4567" not in result["anonymized_text"]
        assert "phone" in result["pii_detected"]
    
    def test_multiple_pii_types(self):
        """Test multiple PII types"""
        anonymizer = DataAnonymizer()
        
        result = anonymizer.anonymize_text(
            "My email is john@example.com and phone is 555-1234"
        )
        
        assert len(result["pii_detected"]) == 2
        assert "email" in result["pii_detected"]
        assert "phone" in result["pii_detected"]


class TestFairnessMetrics:
    """Tests for fairness metrics"""
    
    def test_demographic_parity(self):
        """Test demographic parity calculation"""
        metrics = FairnessMetrics()
        
        predictions = {
            "group_a": [1, 1, 0, 1, 0],
            "group_b": [1, 1, 1, 0, 0]
        }
        
        result = metrics.calculate_demographic_parity(predictions)
        
        assert "max_disparity" in result
        assert "fair" in result
        assert result["metric"] == "demographic_parity"
    
    def test_disparate_impact(self):
        """Test disparate impact calculation"""
        metrics = FairnessMetrics()
        
        predictions = {
            "privileged": [1, 1, 1, 1, 0],
            "unprivileged": [1, 1, 0, 0, 0]
        }
        
        result = metrics.calculate_disparate_impact(predictions)
        
        assert "disparate_impact_ratio" in result
        assert result["metric"] == "disparate_impact"


class TestBiasDetector:
    """Tests for bias detection"""
    
    def test_language_bias_detection(self):
        """Test language bias detection"""
        detector = BiasDetector()
        
        result = detector.detect_language_bias(
            "All elderly patients are frail"
        )
        
        assert result["has_bias"]
        assert len(result["detected_biases"]) > 0
    
    def test_no_bias_detection(self):
        """Test when no bias is present"""
        detector = BiasDetector()
        
        result = detector.detect_language_bias(
            "The patient reports symptoms"
        )
        
        assert not result["has_bias"]
        assert len(result["detected_biases"]) == 0


# Run tests
if __name__ == "__main__":
    pytest.main([__file__, "-v", "--cov=src"])
