#!/bin/bash

# Create directory structure
mkdir -p src/{agents,communication,models,utils,security,fairness}
mkdir -p config
mkdir -p data/{raw,processed,anonymized}
mkdir -p logs
mkdir -p tests/{unit,integration}
mkdir -p docs
mkdir -p notebooks
mkdir -p deployment

# Create __init__.py files
touch src/__init__.py
touch src/agents/__init__.py
touch src/communication/__init__.py
touch src/models/__init__.py
touch src/utils/__init__.py
touch src/security/__init__.py
touch src/fairness/__init__.py
touch tests/__init__.py
touch tests/unit/__init__.py
touch tests/integration/__init__.py

echo "Project structure created successfully!"
