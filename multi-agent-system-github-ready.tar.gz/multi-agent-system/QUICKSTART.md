# Quick Start Guide

Get up and running with the Multi-Agent Healthcare System in 5 minutes!

## Prerequisites

- Python 3.9 or higher
- pip (Python package manager)
- Git
- 2GB free disk space

## Installation (5 minutes)

### Step 1: Clone Repository

```bash
git clone https://github.com/yourusername/multi-agent-healthcare-system.git
cd multi-agent-healthcare-system
```

### Step 2: Create Virtual Environment

**On macOS/Linux:**
```bash
python3 -m venv venv
source venv/bin/activate
```

**On Windows:**
```bash
python -m venv venv
venv\Scripts\activate
```

### Step 3: Install Dependencies

```bash
pip install -r requirements.txt
```

This will take 2-3 minutes to install all required packages.

### Step 4: Run the Application

```bash
streamlit run app.py
```

The application will start and open automatically in your browser at `http://localhost:8501`

## First Use

### Try These Example Queries

**Example 1: Common Cold Symptoms**
```
I have a runny nose, sore throat, and mild cough that started yesterday.
I'm 25 years old.
```

**Example 2: Flu-like Symptoms**
```
I've had a high fever (101°F), body aches, headache, and extreme fatigue 
for the past 2 days. No cough or sore throat.
```

**Example 3: Mild Headache**
```
I have a mild headache and feel a bit tired. It started this morning after 
working on my computer for several hours.
```

### What You'll See

1. **Urgency Badge**: Color-coded urgency level (Emergency, High, Medium, Low)
2. **Assessment Results**: Clear explanation of possible conditions
3. **Detected Symptoms**: List of symptoms identified from your description
4. **Possible Conditions**: Matched conditions with confidence scores
5. **Self-Care Recommendations**: What you can do at home
6. **When to Seek Care**: Warning signs to watch for

### Explore the System

**View Agent Communication:**
- Expand "View Agent Communication Details" to see how agents collaborate
- Watch messages flow from Triage → Knowledge → Response agents

**Check System Metrics:**
- Sidebar shows active agents and their performance
- View real-time statistics on conversations processed

**Privacy Controls:**
- Toggle PII anonymization
- Enable/disable ethics monitoring
- View ethics reports

## Configuration (Optional)

### Basic Configuration

Create a `.env` file from the example:

```bash
cp .env.example .env
```

Edit `.env` to customize:

```bash
# Set to false to disable privacy features (not recommended)
ENABLE_PII_DETECTION=True
ENABLE_ANONYMIZATION=True

# Adjust urgency thresholds
FAIRNESS_THRESHOLD=0.1

# Change log level
LOG_LEVEL=INFO
```

### Advanced Configuration

For production deployment, see [DEPLOYMENT.md](docs/DEPLOYMENT.md)

## Understanding the Interface

### Main Query Area
- Large text box for describing symptoms
- Optional fields for age, gender, and chronic conditions
- "Analyze Symptoms" button to submit

### Results Display
1. **Urgency Banner**: Immediate visual indication of urgency
2. **Assessment Results**: Main response with recommendations
3. **Detected Symptoms**: Visual cards showing identified symptoms
4. **Possible Conditions**: Expandable cards with detailed information
5. **Agent Communication**: Technical view of inter-agent messages

### Sidebar Information
- **Active Agents**: Status of each agent
- **System Metrics**: Performance statistics
- **Privacy & Ethics**: Control panel for ethical AI features
- **Disclaimer**: Important medical information

## Testing the System

### Run Automated Tests

```bash
# Install test dependencies (if not already installed)
pip install pytest pytest-asyncio pytest-cov

# Run all tests
pytest tests/ -v

# Run with coverage report
pytest tests/ --cov=src --cov-report=html

# View coverage report
open htmlcov/index.html  # macOS
xdg-open htmlcov/index.html  # Linux
start htmlcov/index.html  # Windows
```

### Manual Testing Scenarios

**Test 1: Emergency Detection**
Input: "I'm having severe chest pain and difficulty breathing"
Expected: Emergency urgency level, immediate care recommendation

**Test 2: Privacy Protection**
Input: "Contact me at john@example.com or call 555-1234"
Expected: Email and phone number anonymized, privacy notice shown

**Test 3: Multiple Symptoms**
Input: "Headache, fever, nausea, dizziness, and fatigue"
Expected: Multiple conditions matched, prioritized by confidence

## Common Issues & Solutions

### Issue: Application Won't Start

**Symptom:** Error when running `streamlit run app.py`

**Solution:**
```bash
# Check Python version (must be 3.9+)
python --version

# Reinstall dependencies
pip install -r requirements.txt --force-reinstall

# Clear Streamlit cache
rm -rf ~/.streamlit/
```

### Issue: Import Errors

**Symptom:** `ModuleNotFoundError: No module named 'src'`

**Solution:**
```bash
# Ensure you're in the correct directory
pwd  # Should show .../multi-agent-healthcare-system

# Activate virtual environment
source venv/bin/activate  # macOS/Linux
venv\Scripts\activate     # Windows

# Verify installation
pip list | grep streamlit
```

### Issue: Port Already in Use

**Symptom:** `Address already in use: 8501`

**Solution:**
```bash
# Use different port
streamlit run app.py --server.port 8502

# Or kill process using port 8501
lsof -ti:8501 | xargs kill  # macOS/Linux
netstat -ano | findstr :8501  # Windows (find PID, then kill)
```

### Issue: Slow Response Times

**Solution:**
- First run may be slower (initializing agents)
- Subsequent queries should be faster
- Check system resources (RAM, CPU)
- Consider enabling Redis caching (see Configuration)

## Next Steps

### Learn More
- Read [BLOG_POST.md](docs/BLOG_POST.md) for non-technical explanation
- Review [README.md](README.md) for comprehensive documentation
- Check [DEPLOYMENT.md](docs/DEPLOYMENT.md) for production deployment

### Customize
- Modify knowledge base in `src/agents/knowledge_agent.py`
- Add new agents by extending `src/agents/base_agent.py`
- Customize UI in `app.py`

### Contribute
- Report issues on GitHub
- Submit pull requests
- Suggest improvements
- Share your experience

## Example Code Usage

### Programmatic API

```python
import asyncio
from src.agents.orchestrator import AgentOrchestrator

async def main():
    # Initialize orchestrator
    orchestrator = AgentOrchestrator()
    
    # Process query
    result = await orchestrator.process_user_query(
        query="I have a headache and fever",
        user_data={"age": 30, "gender": "female"}
    )
    
    # Access results
    print(f"Urgency: {result['urgency_level']}")
    print(f"Symptoms: {result['extracted_symptoms']}")
    print(f"Response: {result['response_text']}")

# Run
asyncio.run(main())
```

### Privacy Features

```python
from src.security.privacy import DataAnonymizer

# Anonymize text
anonymizer = DataAnonymizer()
result = anonymizer.anonymize_text(
    "Contact me at john@example.com"
)
print(result['anonymized_text'])  # "Contact me at [EMAIL]"
print(result['pii_detected'])     # ['email']
```

### Fairness Metrics

```python
from src.fairness.bias_detection import FairnessMetrics

metrics = FairnessMetrics()

# Check demographic parity
predictions = {
    "group_a": [1, 1, 0, 1, 0],
    "group_b": [1, 0, 0, 1, 1]
}

result = metrics.calculate_demographic_parity(predictions)
print(f"Fair: {result['fair']}")
print(f"Disparity: {result['max_disparity']}")
```

## Development Mode

### Enable Debug Logging

Edit `.env`:
```bash
DEBUG=True
LOG_LEVEL=DEBUG
```

### Watch for Changes

Streamlit auto-reloads when you save files!

### Access Logs

```bash
# Application logs
tail -f logs/application.log

# GDPR logs
tail -f logs/gdpr_compliance.jsonl
```

## Getting Help

### Resources
- **Documentation**: Check `docs/` folder
- **GitHub Issues**: Report bugs or ask questions
- **Code Comments**: Extensive inline documentation
- **Tests**: See `tests/` for usage examples

### Contact
- Email: your.email@example.com
- GitHub: @yourusername
- LinkedIn: linkedin.com/in/yourprofile

---

**Congratulations!** 🎉 You're now running a production-ready multi-agent AI healthcare system!

**Remember:** This is for educational purposes only. Always consult healthcare professionals for medical advice.

## What's Next?

Try these challenges:
1. Add a new symptom to the knowledge base
2. Create a custom agent
3. Implement additional privacy features
4. Deploy to the cloud
5. Contribute improvements back to the project

Happy coding! 🚀
