"""
Privacy and Data Anonymization Module
Implements GDPR-compliant data handling and PII protection
"""

from typing import Dict, Any, List, Optional
import re
import hashlib
import json
from datetime import datetime
from faker import Faker
import structlog

logger = structlog.get_logger()


class DataAnonymizer:
    """
    Handles data anonymization and PII detection/removal.
    Implements GDPR Article 32 requirements for data protection.
    """
    
    def __init__(self):
        self.faker = Faker()
        self.logger = structlog.get_logger().bind(component="anonymizer")
        
        # PII patterns
        self.pii_patterns = {
            "email": r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b',
            "phone": r'\b(\+\d{1,3}[-.]?)?\(?\d{3}\)?[-.]?\d{3}[-.]?\d{4}\b',
            "ssn": r'\b\d{3}-\d{2}-\d{4}\b',
            "credit_card": r'\b\d{4}[-\s]?\d{4}[-\s]?\d{4}[-\s]?\d{4}\b',
            "ip_address": r'\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b',
            "date_of_birth": r'\b\d{1,2}[/-]\d{1,2}[/-]\d{2,4}\b'
        }
        
        # Anonymization cache for consistency
        self.anonymization_cache = {}
    
    def anonymize_text(
        self,
        text: str,
        preserve_format: bool = True
    ) -> Dict[str, Any]:
        """
        Anonymize PII in text.
        
        Returns:
            Dict with anonymized text and detected PII types
        """
        if not text:
            return {"anonymized_text": text, "pii_detected": []}
        
        anonymized = text
        detected_pii = []
        
        # Detect and replace each PII type
        for pii_type, pattern in self.pii_patterns.items():
            matches = re.finditer(pattern, text)
            
            for match in matches:
                original = match.group(0)
                
                # Check cache for consistent anonymization
                cache_key = f"{pii_type}:{original}"
                if cache_key in self.anonymization_cache:
                    replacement = self.anonymization_cache[cache_key]
                else:
                    replacement = self._generate_replacement(pii_type, preserve_format)
                    self.anonymization_cache[cache_key] = replacement
                
                anonymized = anonymized.replace(original, replacement)
                detected_pii.append(pii_type)
        
        # Remove duplicates from detected PII
        detected_pii = list(set(detected_pii))
        
        if detected_pii:
            self.logger.info(
                "pii_anonymized",
                pii_types=detected_pii,
                num_occurrences=len(detected_pii)
            )
        
        return {
            "anonymized_text": anonymized,
            "pii_detected": detected_pii,
            "original_length": len(text),
            "anonymized_length": len(anonymized)
        }
    
    def _generate_replacement(self, pii_type: str, preserve_format: bool) -> str:
        """Generate replacement value for PII"""
        if pii_type == "email":
            return self.faker.email() if preserve_format else "[EMAIL]"
        elif pii_type == "phone":
            return self.faker.phone_number() if preserve_format else "[PHONE]"
        elif pii_type == "ssn":
            return "XXX-XX-XXXX" if preserve_format else "[SSN]"
        elif pii_type == "credit_card":
            return "XXXX-XXXX-XXXX-XXXX" if preserve_format else "[CREDIT_CARD]"
        elif pii_type == "ip_address":
            return "XXX.XXX.XXX.XXX" if preserve_format else "[IP]"
        elif pii_type == "date_of_birth":
            return "XX/XX/XXXX" if preserve_format else "[DOB]"
        else:
            return "[REDACTED]"
    
    def anonymize_user_data(
        self,
        user_data: Dict[str, Any],
        fields_to_anonymize: Optional[List[str]] = None
    ) -> Dict[str, Any]:
        """
        Anonymize user data dictionary.
        
        Args:
            user_data: User data dictionary
            fields_to_anonymize: Specific fields to anonymize (None = all PII fields)
        """
        if fields_to_anonymize is None:
            # Default PII fields in user data
            fields_to_anonymize = [
                "name", "email", "phone", "address", "ssn",
                "date_of_birth", "ip_address"
            ]
        
        anonymized = user_data.copy()
        
        for field in fields_to_anonymize:
            if field in anonymized:
                value = anonymized[field]
                
                if isinstance(value, str):
                    # Anonymize text fields
                    result = self.anonymize_text(value)
                    anonymized[field] = result["anonymized_text"]
                elif field == "date_of_birth":
                    # Anonymize but preserve age group
                    anonymized[field] = self._anonymize_date(value)
        
        return anonymized
    
    def _anonymize_date(self, date_value: Any) -> str:
        """Anonymize date while preserving age group"""
        # Convert to age group instead of exact date
        # This maintains utility while protecting privacy
        return "[DATE_ANONYMIZED]"
    
    def hash_identifier(self, identifier: str) -> str:
        """
        Create a one-way hash of an identifier.
        Useful for creating pseudonymous IDs that can't be reversed.
        """
        return hashlib.sha256(identifier.encode()).hexdigest()
    
    def create_pseudonym(self, user_id: str) -> str:
        """
        Create a consistent pseudonym for a user.
        Same user always gets same pseudonym.
        """
        cache_key = f"pseudonym:{user_id}"
        if cache_key in self.anonymization_cache:
            return self.anonymization_cache[cache_key]
        
        # Generate pseudonym
        pseudonym = f"User_{hashlib.md5(user_id.encode()).hexdigest()[:8]}"
        self.anonymization_cache[cache_key] = pseudonym
        
        return pseudonym


class GDPRComplianceLogger:
    """
    GDPR-compliant logging for data processing activities.
    Implements Article 30 record of processing activities.
    """
    
    def __init__(self, log_file: Optional[str] = None):
        self.log_file = log_file or "logs/gdpr_compliance.jsonl"
        self.logger = structlog.get_logger().bind(component="gdpr_logger")
    
    def log_data_access(
        self,
        user_id: str,
        data_type: str,
        purpose: str,
        legal_basis: str = "consent"
    ) -> None:
        """
        Log data access event.
        
        Args:
            user_id: User identifier (pseudonymized)
            data_type: Type of data accessed
            purpose: Purpose of data processing
            legal_basis: GDPR legal basis (consent, legitimate interest, etc.)
        """
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": "data_access",
            "user_id": user_id,
            "data_type": data_type,
            "purpose": purpose,
            "legal_basis": legal_basis
        }
        
        self._write_log(log_entry)
        
        self.logger.info(
            "data_access_logged",
            user_id=user_id,
            data_type=data_type
        )
    
    def log_data_deletion(self, user_id: str, data_deleted: List[str]) -> None:
        """Log data deletion (right to be forgotten)"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": "data_deletion",
            "user_id": user_id,
            "data_deleted": data_deleted
        }
        
        self._write_log(log_entry)
        
        self.logger.info(
            "data_deletion_logged",
            user_id=user_id,
            num_items=len(data_deleted)
        )
    
    def log_consent(
        self,
        user_id: str,
        consent_type: str,
        granted: bool
    ) -> None:
        """Log user consent"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": "consent",
            "user_id": user_id,
            "consent_type": consent_type,
            "granted": granted
        }
        
        self._write_log(log_entry)
        
        self.logger.info(
            "consent_logged",
            user_id=user_id,
            consent_type=consent_type,
            granted=granted
        )
    
    def log_data_breach(
        self,
        description: str,
        affected_users: int,
        severity: str
    ) -> None:
        """Log data breach (GDPR Article 33)"""
        log_entry = {
            "timestamp": datetime.utcnow().isoformat(),
            "event_type": "data_breach",
            "description": description,
            "affected_users": affected_users,
            "severity": severity,
            "notification_required": affected_users > 0
        }
        
        self._write_log(log_entry)
        
        self.logger.error(
            "data_breach_logged",
            affected_users=affected_users,
            severity=severity
        )
    
    def _write_log(self, log_entry: Dict[str, Any]) -> None:
        """Write log entry to file"""
        try:
            with open(self.log_file, "a") as f:
                f.write(json.dumps(log_entry) + "\n")
        except Exception as e:
            self.logger.error("failed_to_write_log", error=str(e))


class DataRetentionPolicy:
    """
    Implements data retention policies for GDPR compliance.
    """
    
    def __init__(self, default_retention_days: int = 90):
        self.default_retention_days = default_retention_days
        self.retention_policies = {
            "conversation_logs": 90,  # 90 days
            "user_queries": 30,  # 30 days
            "anonymized_analytics": 365,  # 1 year
            "consent_records": 2555  # 7 years (legal requirement)
        }
        self.logger = structlog.get_logger().bind(component="retention_policy")
    
    def should_delete(
        self,
        data_type: str,
        created_date: datetime
    ) -> bool:
        """
        Check if data should be deleted based on retention policy.
        """
        retention_days = self.retention_policies.get(
            data_type,
            self.default_retention_days
        )
        
        age_days = (datetime.utcnow() - created_date).days
        
        should_delete = age_days > retention_days
        
        if should_delete:
            self.logger.info(
                "data_retention_expired",
                data_type=data_type,
                age_days=age_days,
                retention_days=retention_days
            )
        
        return should_delete
    
    def get_retention_period(self, data_type: str) -> int:
        """Get retention period in days for data type"""
        return self.retention_policies.get(data_type, self.default_retention_days)
