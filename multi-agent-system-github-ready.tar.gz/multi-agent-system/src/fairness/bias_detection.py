"""
Fairness and Bias Detection Module
Implements fairness metrics and bias detection for ethical AI
"""

from typing import Dict, Any, List, Optional, Tuple
import numpy as np
from collections import defaultdict
import structlog

logger = structlog.get_logger()


class FairnessMetrics:
    """
    Implements various fairness metrics for AI systems.
    Based on frameworks like Fairlearn and AIF360.
    """
    
    def __init__(self):
        self.logger = structlog.get_logger().bind(component="fairness_metrics")
        
        # Track predictions by demographic group
        self.predictions_by_group = defaultdict(list)
        self.outcomes_by_group = defaultdict(list)
    
    def calculate_demographic_parity(
        self,
        predictions: Dict[str, List[int]],
        threshold: float = 0.1
    ) -> Dict[str, Any]:
        """
        Calculate demographic parity (statistical parity).
        
        Demographic parity is satisfied when P(Ŷ=1|A=a) = P(Ŷ=1|A=b)
        for all groups a, b in sensitive attribute A.
        
        Args:
            predictions: Dict mapping group names to binary predictions
            threshold: Acceptable disparity threshold
        
        Returns:
            Dict with fairness assessment
        """
        if not predictions or len(predictions) < 2:
            return {"status": "insufficient_data", "fair": None}
        
        # Calculate positive prediction rate for each group
        positive_rates = {}
        for group, preds in predictions.items():
            if len(preds) == 0:
                continue
            positive_rates[group] = sum(preds) / len(preds)
        
        # Calculate maximum disparity
        rates = list(positive_rates.values())
        max_disparity = max(rates) - min(rates) if rates else 0
        
        is_fair = max_disparity <= threshold
        
        result = {
            "metric": "demographic_parity",
            "positive_rates": positive_rates,
            "max_disparity": round(max_disparity, 4),
            "threshold": threshold,
            "fair": is_fair,
            "status": "pass" if is_fair else "fail"
        }
        
        self.logger.info(
            "demographic_parity_calculated",
            max_disparity=max_disparity,
            is_fair=is_fair
        )
        
        return result
    
    def calculate_equalized_odds(
        self,
        predictions: Dict[str, List[int]],
        true_labels: Dict[str, List[int]],
        threshold: float = 0.1
    ) -> Dict[str, Any]:
        """
        Calculate equalized odds fairness metric.
        
        Equalized odds requires:
        - P(Ŷ=1|Y=1,A=a) = P(Ŷ=1|Y=1,A=b) (equal TPR)
        - P(Ŷ=1|Y=0,A=a) = P(Ŷ=1|Y=0,A=b) (equal FPR)
        
        Args:
            predictions: Dict mapping group names to binary predictions
            true_labels: Dict mapping group names to true labels
            threshold: Acceptable disparity threshold
        """
        if not predictions or len(predictions) < 2:
            return {"status": "insufficient_data", "fair": None}
        
        tpr_by_group = {}
        fpr_by_group = {}
        
        for group in predictions.keys():
            if group not in true_labels:
                continue
            
            preds = np.array(predictions[group])
            labels = np.array(true_labels[group])
            
            if len(preds) == 0 or len(labels) == 0:
                continue
            
            # Calculate TPR and FPR
            tp = np.sum((preds == 1) & (labels == 1))
            fn = np.sum((preds == 0) & (labels == 1))
            fp = np.sum((preds == 1) & (labels == 0))
            tn = np.sum((preds == 0) & (labels == 0))
            
            tpr = tp / (tp + fn) if (tp + fn) > 0 else 0
            fpr = fp / (fp + tn) if (fp + tn) > 0 else 0
            
            tpr_by_group[group] = tpr
            fpr_by_group[group] = fpr
        
        # Calculate disparities
        tpr_values = list(tpr_by_group.values())
        fpr_values = list(fpr_by_group.values())
        
        tpr_disparity = max(tpr_values) - min(tpr_values) if tpr_values else 0
        fpr_disparity = max(fpr_values) - min(fpr_values) if fpr_values else 0
        
        max_disparity = max(tpr_disparity, fpr_disparity)
        is_fair = max_disparity <= threshold
        
        result = {
            "metric": "equalized_odds",
            "tpr_by_group": {k: round(v, 4) for k, v in tpr_by_group.items()},
            "fpr_by_group": {k: round(v, 4) for k, v in fpr_by_group.items()},
            "tpr_disparity": round(tpr_disparity, 4),
            "fpr_disparity": round(fpr_disparity, 4),
            "max_disparity": round(max_disparity, 4),
            "threshold": threshold,
            "fair": is_fair,
            "status": "pass" if is_fair else "fail"
        }
        
        self.logger.info(
            "equalized_odds_calculated",
            tpr_disparity=tpr_disparity,
            fpr_disparity=fpr_disparity,
            is_fair=is_fair
        )
        
        return result
    
    def calculate_disparate_impact(
        self,
        predictions: Dict[str, List[int]],
        threshold: float = 0.8
    ) -> Dict[str, Any]:
        """
        Calculate disparate impact ratio.
        
        Disparate impact ratio = (favorable outcomes for unprivileged) / 
                                 (favorable outcomes for privileged)
        
        Fair if ratio >= 0.8 (80% rule)
        """
        if not predictions or len(predictions) != 2:
            return {"status": "requires_two_groups", "fair": None}
        
        groups = list(predictions.keys())
        group1, group2 = groups[0], groups[1]
        
        rate1 = sum(predictions[group1]) / len(predictions[group1]) if predictions[group1] else 0
        rate2 = sum(predictions[group2]) / len(predictions[group2]) if predictions[group2] else 0
        
        # Calculate ratio (lower rate / higher rate)
        if rate1 == 0 and rate2 == 0:
            ratio = 1.0
        elif rate1 == 0 or rate2 == 0:
            ratio = 0.0
        else:
            ratio = min(rate1, rate2) / max(rate1, rate2)
        
        is_fair = ratio >= threshold
        
        result = {
            "metric": "disparate_impact",
            "group1": group1,
            "group2": group2,
            "rate_group1": round(rate1, 4),
            "rate_group2": round(rate2, 4),
            "disparate_impact_ratio": round(ratio, 4),
            "threshold": threshold,
            "fair": is_fair,
            "status": "pass" if is_fair else "fail"
        }
        
        self.logger.info(
            "disparate_impact_calculated",
            ratio=ratio,
            is_fair=is_fair
        )
        
        return result


class BiasDetector:
    """
    Detects various types of bias in AI system outputs.
    """
    
    def __init__(self):
        self.logger = structlog.get_logger().bind(component="bias_detector")
        
        # Sensitive terms that might indicate bias
        self.sensitive_terms = {
            "gender": ["he", "she", "his", "her", "man", "woman", "male", "female"],
            "age": ["young", "old", "elderly", "teenager", "senior"],
            "race": ["black", "white", "asian", "hispanic", "african"],
            "socioeconomic": ["poor", "rich", "wealthy", "low-income"]
        }
    
    def detect_language_bias(
        self,
        text: str,
        context: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Detect biased language in text.
        
        Returns:
            Dict with bias assessment and recommendations
        """
        text_lower = text.lower()
        detected_biases = []
        
        # Check for sensitive terms
        for category, terms in self.sensitive_terms.items():
            found_terms = [term for term in terms if term in text_lower]
            if found_terms:
                detected_biases.append({
                    "category": category,
                    "terms_found": found_terms,
                    "severity": "medium"
                })
        
        # Check for stereotype patterns
        stereotype_patterns = [
            (r"all .* are", "overgeneralization"),
            (r"never .* because", "absolute_statement"),
            (r"always .* tend to", "stereotype")
        ]
        
        import re
        for pattern, bias_type in stereotype_patterns:
            if re.search(pattern, text_lower):
                detected_biases.append({
                    "type": bias_type,
                    "pattern": pattern,
                    "severity": "high"
                })
        
        has_bias = len(detected_biases) > 0
        
        result = {
            "has_bias": has_bias,
            "detected_biases": detected_biases,
            "num_issues": len(detected_biases),
            "text_length": len(text),
            "recommendations": self._generate_bias_recommendations(detected_biases)
        }
        
        if has_bias:
            self.logger.warning(
                "language_bias_detected",
                num_issues=len(detected_biases),
                categories=[b.get("category") for b in detected_biases if "category" in b]
            )
        
        return result
    
    def _generate_bias_recommendations(
        self,
        detected_biases: List[Dict[str, Any]]
    ) -> List[str]:
        """Generate recommendations for addressing detected biases"""
        recommendations = []
        
        categories = {b.get("category") for b in detected_biases if "category" in b}
        
        if "gender" in categories:
            recommendations.append(
                "Use gender-neutral language where possible (e.g., 'they' instead of 'he/she')"
            )
        
        if "age" in categories:
            recommendations.append(
                "Avoid age-based assumptions; focus on relevant characteristics"
            )
        
        if "race" in categories:
            recommendations.append(
                "Ensure racial/ethnic terms are used appropriately and respectfully"
            )
        
        # Check for stereotypes
        stereotype_types = {b.get("type") for b in detected_biases if "type" in b}
        if stereotype_types:
            recommendations.append(
                "Avoid overgeneralizations and stereotypes; acknowledge individual variation"
            )
        
        return recommendations
    
    def detect_representation_bias(
        self,
        data_distribution: Dict[str, int],
        expected_distribution: Optional[Dict[str, float]] = None
    ) -> Dict[str, Any]:
        """
        Detect representation bias in data distribution.
        
        Args:
            data_distribution: Actual count of items per group
            expected_distribution: Expected proportion per group (optional)
        """
        total_items = sum(data_distribution.values())
        if total_items == 0:
            return {"status": "no_data", "has_bias": None}
        
        actual_proportions = {
            group: count / total_items
            for group, count in data_distribution.items()
        }
        
        # If no expected distribution, check for severe imbalance
        if expected_distribution is None:
            # Check if any group is severely underrepresented (< 10%)
            min_proportion = min(actual_proportions.values())
            max_proportion = max(actual_proportions.values())
            
            has_bias = min_proportion < 0.1 or (max_proportion - min_proportion) > 0.6
            
            result = {
                "actual_proportions": {k: round(v, 4) for k, v in actual_proportions.items()},
                "min_proportion": round(min_proportion, 4),
                "max_proportion": round(max_proportion, 4),
                "imbalance_ratio": round(max_proportion / min_proportion if min_proportion > 0 else float('inf'), 2),
                "has_bias": has_bias,
                "status": "imbalanced" if has_bias else "balanced"
            }
        else:
            # Compare with expected distribution
            disparities = {}
            for group in actual_proportions.keys():
                expected = expected_distribution.get(group, 0)
                actual = actual_proportions[group]
                disparities[group] = abs(actual - expected)
            
            max_disparity = max(disparities.values())
            has_bias = max_disparity > 0.15  # 15% threshold
            
            result = {
                "actual_proportions": {k: round(v, 4) for k, v in actual_proportions.items()},
                "expected_proportions": expected_distribution,
                "disparities": {k: round(v, 4) for k, v in disparities.items()},
                "max_disparity": round(max_disparity, 4),
                "has_bias": has_bias,
                "status": "biased" if has_bias else "fair"
            }
        
        if has_bias:
            self.logger.warning(
                "representation_bias_detected",
                proportions=actual_proportions
            )
        
        return result


class EthicalAIMonitor:
    """
    Monitor AI system for ethical concerns and fairness issues.
    """
    
    def __init__(self):
        self.fairness_metrics = FairnessMetrics()
        self.bias_detector = BiasDetector()
        self.logger = structlog.get_logger().bind(component="ethical_monitor")
        
        # Track issues over time
        self.issue_history = []
    
    def evaluate_response(
        self,
        response: str,
        user_demographics: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Evaluate a response for ethical issues.
        
        Args:
            response: Generated response text
            user_demographics: User demographic information
        """
        # Detect language bias
        language_bias = self.bias_detector.detect_language_bias(response)
        
        # Build evaluation report
        evaluation = {
            "timestamp": datetime.utcnow().isoformat(),
            "response_length": len(response),
            "language_bias": language_bias,
            "has_issues": language_bias["has_bias"],
            "recommendations": language_bias.get("recommendations", [])
        }
        
        # Store in history
        if evaluation["has_issues"]:
            self.issue_history.append(evaluation)
            self.logger.warning(
                "ethical_issue_detected",
                num_issues=language_bias["num_issues"]
            )
        
        return evaluation
    
    def generate_ethics_report(self) -> Dict[str, Any]:
        """Generate comprehensive ethics report"""
        total_evaluations = len(self.issue_history)
        issues_detected = len([e for e in self.issue_history if e["has_issues"]])
        
        report = {
            "total_evaluations": total_evaluations,
            "issues_detected": issues_detected,
            "issue_rate": issues_detected / total_evaluations if total_evaluations > 0 else 0,
            "recent_issues": self.issue_history[-10:],  # Last 10 issues
            "status": "healthy" if issues_detected / max(total_evaluations, 1) < 0.1 else "needs_attention"
        }
        
        return report


from datetime import datetime
