"""
Triage Agent - Handles initial symptom intake and routing
"""

from typing import Dict, Any, Optional, List
import re
from datetime import datetime

from .base_agent import BaseAgent, AgentMessage, MessageType, AgentCapability


class TriageAgent(BaseAgent):
    """
    Agent responsible for:
    1. Initial patient/user query processing
    2. Extracting symptoms and key information
    3. Determining severity/urgency
    4. Routing to appropriate agents
    """
    
    def __init__(self):
        super().__init__(
            agent_id="triage_agent",
            name="Triage Agent",
            capabilities=[
                AgentCapability.QUERY_PROCESSING,
                AgentCapability.TRIAGE,
                AgentCapability.DECISION_MAKING
            ],
            description="Processes initial queries and determines routing"
        )
        
        # Urgency keywords for triage
        self.emergency_keywords = [
            "chest pain", "difficulty breathing", "severe bleeding",
            "unconscious", "seizure", "stroke", "heart attack",
            "severe allergic reaction", "suicide", "overdose"
        ]
        
        self.high_priority_keywords = [
            "severe pain", "high fever", "vomiting blood",
            "sudden weakness", "vision loss", "confusion"
        ]
        
        # Symptom categories
        self.symptom_categories = {
            "respiratory": ["cough", "shortness of breath", "wheezing", "sore throat"],
            "gastrointestinal": ["nausea", "vomiting", "diarrhea", "stomach pain"],
            "neurological": ["headache", "dizziness", "confusion", "numbness"],
            "cardiovascular": ["chest pain", "palpitations", "irregular heartbeat"],
            "dermatological": ["rash", "itching", "swelling", "hives"],
            "musculoskeletal": ["joint pain", "muscle ache", "back pain"],
            "general": ["fever", "fatigue", "weakness", "chills"]
        }
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process incoming message"""
        try:
            if message.message_type == MessageType.REQUEST:
                # This is a new query
                result = await self.execute_task(message.content)
                
                return self.send_message(
                    receiver_id=result.get("next_agent", "knowledge_agent"),
                    content=result,
                    message_type=MessageType.REQUEST,
                    conversation_id=message.conversation_id
                )
            
            return None
            
        except Exception as e:
            self.log_error(e, {"message_id": message.message_id})
            return self.send_message(
                receiver_id=message.sender_id,
                content={"error": str(e), "status": "failed"},
                message_type=MessageType.ERROR,
                conversation_id=message.conversation_id
            )
    
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute triage task:
        1. Extract symptoms
        2. Determine urgency
        3. Categorize symptoms
        4. Prepare for knowledge retrieval
        """
        user_query = task.get("query", "")
        user_data = task.get("user_data", {})
        
        # Extract symptoms
        extracted_symptoms = self._extract_symptoms(user_query)
        
        # Determine urgency level
        urgency = self._determine_urgency(user_query, extracted_symptoms)
        
        # Categorize symptoms
        categories = self._categorize_symptoms(extracted_symptoms)
        
        # Extract demographic information
        demographics = self._extract_demographics(user_query, user_data)
        
        # Prepare structured output
        triage_result = {
            "original_query": user_query,
            "extracted_symptoms": extracted_symptoms,
            "symptom_categories": categories,
            "urgency_level": urgency,
            "demographics": demographics,
            "timestamp": datetime.utcnow().isoformat(),
            "triage_notes": self._generate_triage_notes(
                extracted_symptoms, urgency, categories
            ),
            "next_agent": "knowledge_agent",  # Route to knowledge retrieval
            "status": "triaged"
        }
        
        # Update agent state
        self.update_state("last_triage", triage_result)
        self.performance_metrics["tasks_completed"] += 1
        
        self.logger.info(
            "triage_completed",
            urgency=urgency,
            num_symptoms=len(extracted_symptoms),
            categories=list(categories.keys())
        )
        
        return triage_result
    
    def _extract_symptoms(self, query: str) -> List[str]:
        """Extract symptoms from user query"""
        query_lower = query.lower()
        symptoms = []
        
        # Check all symptom categories
        for category, symptom_list in self.symptom_categories.items():
            for symptom in symptom_list:
                if symptom in query_lower:
                    symptoms.append(symptom)
        
        # Remove duplicates while preserving order
        symptoms = list(dict.fromkeys(symptoms))
        
        return symptoms
    
    def _determine_urgency(
        self,
        query: str,
        symptoms: List[str]
    ) -> str:
        """
        Determine urgency level:
        - emergency: Requires immediate medical attention
        - high: Needs prompt attention within hours
        - medium: Should see doctor within days
        - low: Can manage with self-care or routine appointment
        """
        query_lower = query.lower()
        
        # Check for emergency keywords
        for keyword in self.emergency_keywords:
            if keyword in query_lower:
                return "emergency"
        
        # Check for high priority keywords
        for keyword in self.high_priority_keywords:
            if keyword in query_lower:
                return "high"
        
        # Check symptom duration if mentioned
        if any(word in query_lower for word in ["weeks", "persistent", "worsening"]):
            return "medium"
        
        # Default to low for general symptoms
        if len(symptoms) <= 2:
            return "low"
        
        return "medium"
    
    def _categorize_symptoms(self, symptoms: List[str]) -> Dict[str, List[str]]:
        """Categorize symptoms by body system"""
        categories = {}
        
        for symptom in symptoms:
            for category, symptom_list in self.symptom_categories.items():
                if symptom in symptom_list:
                    if category not in categories:
                        categories[category] = []
                    categories[category].append(symptom)
        
        return categories
    
    def _extract_demographics(
        self,
        query: str,
        user_data: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Extract or retrieve demographic information"""
        demographics = {
            "age": user_data.get("age"),
            "gender": user_data.get("gender"),
            "has_chronic_conditions": user_data.get("chronic_conditions", False)
        }
        
        # Try to extract age from query if not provided
        if not demographics["age"]:
            age_match = re.search(r'\b(\d{1,3})\s*(?:year|yr|y\.o\.|years old)', query.lower())
            if age_match:
                demographics["age"] = int(age_match.group(1))
        
        return demographics
    
    def _generate_triage_notes(
        self,
        symptoms: List[str],
        urgency: str,
        categories: Dict[str, List[str]]
    ) -> str:
        """Generate human-readable triage notes"""
        notes_parts = []
        
        # Urgency statement
        urgency_statements = {
            "emergency": "IMMEDIATE MEDICAL ATTENTION REQUIRED",
            "high": "Prompt medical evaluation recommended within 24 hours",
            "medium": "Medical consultation advised within 2-3 days",
            "low": "Routine care or self-management appropriate"
        }
        notes_parts.append(urgency_statements.get(urgency, ""))
        
        # Symptoms summary
        if symptoms:
            notes_parts.append(f"Reported symptoms: {', '.join(symptoms)}")
        
        # Category summary
        if categories:
            cat_summary = ", ".join([
                f"{len(symp)} {cat}" for cat, symp in categories.items()
            ])
            notes_parts.append(f"Affected systems: {cat_summary}")
        
        return " | ".join(notes_parts)
