"""
Knowledge Retrieval Agent - Retrieves medical information from knowledge base
"""

from typing import Dict, Any, Optional, List
import json

from .base_agent import BaseAgent, AgentMessage, MessageType, AgentCapability


class KnowledgeAgent(BaseAgent):
    """
    Agent responsible for:
    1. Retrieving relevant medical information
    2. Matching symptoms to conditions
    3. Providing evidence-based information
    4. Context enrichment for response generation
    """
    
    def __init__(self):
        super().__init__(
            agent_id="knowledge_agent",
            name="Knowledge Retrieval Agent",
            capabilities=[AgentCapability.KNOWLEDGE_RETRIEVAL],
            description="Retrieves medical knowledge and matches symptoms to conditions"
        )
        
        # Simulated medical knowledge base
        # In production, this would connect to a real medical database
        self.knowledge_base = self._initialize_knowledge_base()
    
    def _initialize_knowledge_base(self) -> Dict[str, Any]:
        """Initialize medical knowledge base with common conditions"""
        return {
            "common_cold": {
                "name": "Common Cold",
                "symptoms": ["cough", "sore throat", "runny nose", "sneezing", "fatigue"],
                "category": "respiratory",
                "severity": "low",
                "typical_duration": "7-10 days",
                "self_care": [
                    "Rest and stay hydrated",
                    "Over-the-counter pain relievers for discomfort",
                    "Warm liquids can soothe throat",
                    "Humidifier may help with congestion"
                ],
                "when_to_seek_care": [
                    "Symptoms persist beyond 10 days",
                    "High fever (>101.5°F)",
                    "Severe headache or sinus pain",
                    "Difficulty breathing"
                ]
            },
            "influenza": {
                "name": "Influenza (Flu)",
                "symptoms": ["fever", "chills", "muscle ache", "cough", "fatigue", "headache"],
                "category": "respiratory",
                "severity": "medium",
                "typical_duration": "1-2 weeks",
                "self_care": [
                    "Rest and plenty of fluids",
                    "Antiviral medication (if prescribed within 48 hours)",
                    "Pain relievers for fever and aches",
                    "Isolate to prevent spread"
                ],
                "when_to_seek_care": [
                    "Difficulty breathing or chest pain",
                    "Persistent vomiting",
                    "Confusion or dizziness",
                    "Symptoms improve then worsen"
                ]
            },
            "migraine": {
                "name": "Migraine Headache",
                "symptoms": ["headache", "nausea", "sensitivity to light", "vision changes"],
                "category": "neurological",
                "severity": "medium",
                "typical_duration": "4-72 hours",
                "self_care": [
                    "Rest in dark, quiet room",
                    "Cold compress on forehead",
                    "Over-the-counter pain relievers (early treatment)",
                    "Stay hydrated"
                ],
                "when_to_seek_care": [
                    "Sudden, severe headache ('thunderclap')",
                    "Headache with fever or stiff neck",
                    "New onset after age 50",
                    "Headache following head injury"
                ]
            },
            "gastroenteritis": {
                "name": "Gastroenteritis (Stomach Flu)",
                "symptoms": ["nausea", "vomiting", "diarrhea", "stomach pain", "fever"],
                "category": "gastrointestinal",
                "severity": "medium",
                "typical_duration": "1-3 days",
                "self_care": [
                    "Stay hydrated with clear fluids",
                    "Electrolyte solutions (sports drinks, oral rehydration)",
                    "Bland diet when able to eat (BRAT: bananas, rice, applesauce, toast)",
                    "Rest"
                ],
                "when_to_seek_care": [
                    "Signs of dehydration (dark urine, dizziness)",
                    "Blood in vomit or stool",
                    "Severe abdominal pain",
                    "Symptoms persist beyond 3 days"
                ]
            },
            "allergic_reaction": {
                "name": "Allergic Reaction",
                "symptoms": ["rash", "itching", "swelling", "hives", "runny nose", "sneezing"],
                "category": "dermatological",
                "severity": "low_to_high",
                "typical_duration": "Hours to days",
                "self_care": [
                    "Avoid known allergens",
                    "Antihistamines for mild reactions",
                    "Cold compress for skin reactions",
                    "Stay calm and monitor symptoms"
                ],
                "when_to_seek_care": [
                    "Difficulty breathing or swallowing",
                    "Rapid swelling of lips, tongue, or throat",
                    "Dizziness or fainting",
                    "Widespread rash or severe symptoms"
                ]
            },
            "tension_headache": {
                "name": "Tension Headache",
                "symptoms": ["headache", "muscle ache", "fatigue"],
                "category": "neurological",
                "severity": "low",
                "typical_duration": "30 minutes to several hours",
                "self_care": [
                    "Rest in comfortable position",
                    "Gentle neck and shoulder stretches",
                    "Over-the-counter pain relievers",
                    "Stress management techniques"
                ],
                "when_to_seek_care": [
                    "Headaches becoming more frequent",
                    "Sudden change in headache pattern",
                    "Accompanied by neurological symptoms",
                    "Not responding to usual treatment"
                ]
            }
        }
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process incoming message from triage agent"""
        try:
            if message.message_type == MessageType.REQUEST:
                # Retrieve knowledge based on triage results
                result = await self.execute_task(message.content)
                
                # Send to response generator
                return self.send_message(
                    receiver_id="response_agent",
                    content=result,
                    message_type=MessageType.REQUEST,
                    conversation_id=message.conversation_id
                )
            
            return None
            
        except Exception as e:
            self.log_error(e, {"message_id": message.message_id})
            return self.send_message(
                receiver_id=message.sender_id,
                content={"error": str(e), "status": "failed"},
                message_type=MessageType.ERROR,
                conversation_id=message.conversation_id
            )
    
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute knowledge retrieval:
        1. Match symptoms to possible conditions
        2. Rank by relevance
        3. Retrieve detailed information
        4. Prepare context for response generation
        """
        extracted_symptoms = task.get("extracted_symptoms", [])
        symptom_categories = task.get("symptom_categories", {})
        urgency_level = task.get("urgency_level", "low")
        
        # Match symptoms to conditions
        matched_conditions = self._match_conditions(
            extracted_symptoms,
            symptom_categories
        )
        
        # Retrieve detailed information for top matches
        condition_details = self._retrieve_condition_details(matched_conditions)
        
        # Generate general advice based on urgency
        general_advice = self._generate_general_advice(urgency_level)
        
        # Prepare enriched context
        knowledge_result = {
            **task,  # Include all triage information
            "matched_conditions": matched_conditions,
            "condition_details": condition_details,
            "general_advice": general_advice,
            "knowledge_retrieved": True,
            "num_conditions_found": len(matched_conditions),
            "status": "knowledge_retrieved"
        }
        
        self.update_state("last_retrieval", knowledge_result)
        self.performance_metrics["tasks_completed"] += 1
        
        self.logger.info(
            "knowledge_retrieved",
            num_conditions=len(matched_conditions),
            urgency=urgency_level
        )
        
        return knowledge_result
    
    def _match_conditions(
        self,
        symptoms: List[str],
        categories: Dict[str, List[str]]
    ) -> List[Dict[str, Any]]:
        """Match symptoms to possible conditions with confidence scores"""
        matches = []
        
        for condition_id, condition_data in self.knowledge_base.items():
            # Calculate match score
            condition_symptoms = set(condition_data["symptoms"])
            user_symptoms = set(symptoms)
            
            # Number of matching symptoms
            matching_symptoms = condition_symptoms.intersection(user_symptoms)
            match_count = len(matching_symptoms)
            
            if match_count > 0:
                # Calculate confidence score
                # Based on: (matching symptoms / total user symptoms) * weight
                precision = match_count / len(user_symptoms) if user_symptoms else 0
                recall = match_count / len(condition_symptoms) if condition_symptoms else 0
                confidence = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                
                matches.append({
                    "condition_id": condition_id,
                    "condition_name": condition_data["name"],
                    "confidence_score": round(confidence, 2),
                    "matching_symptoms": list(matching_symptoms),
                    "match_count": match_count,
                    "severity": condition_data["severity"]
                })
        
        # Sort by confidence score (descending)
        matches.sort(key=lambda x: x["confidence_score"], reverse=True)
        
        # Return top 3 matches
        return matches[:3]
    
    def _retrieve_condition_details(
        self,
        matched_conditions: List[Dict[str, Any]]
    ) -> List[Dict[str, Any]]:
        """Retrieve detailed information for matched conditions"""
        details = []
        
        for match in matched_conditions:
            condition_id = match["condition_id"]
            condition_data = self.knowledge_base.get(condition_id, {})
            
            details.append({
                "condition_name": condition_data.get("name"),
                "confidence": match["confidence_score"],
                "matching_symptoms": match["matching_symptoms"],
                "typical_duration": condition_data.get("typical_duration"),
                "self_care": condition_data.get("self_care", []),
                "when_to_seek_care": condition_data.get("when_to_seek_care", []),
                "severity": condition_data.get("severity")
            })
        
        return details
    
    def _generate_general_advice(self, urgency_level: str) -> Dict[str, Any]:
        """Generate general medical advice based on urgency"""
        advice = {
            "emergency": {
                "message": "⚠️ SEEK IMMEDIATE MEDICAL ATTENTION",
                "actions": [
                    "Call 911 or go to nearest emergency room",
                    "Do not drive yourself if symptoms are severe",
                    "Have someone stay with you"
                ],
                "disclaimer": "This is a medical emergency. Professional help is needed immediately."
            },
            "high": {
                "message": "Prompt medical evaluation recommended",
                "actions": [
                    "Contact your healthcare provider within 24 hours",
                    "Visit urgent care if primary care unavailable",
                    "Monitor symptoms closely"
                ],
                "disclaimer": "While not immediately life-threatening, these symptoms warrant prompt professional evaluation."
            },
            "medium": {
                "message": "Medical consultation advised",
                "actions": [
                    "Schedule appointment with healthcare provider within 2-3 days",
                    "Monitor symptoms for any worsening",
                    "Try recommended self-care measures"
                ],
                "disclaimer": "Professional medical advice can help determine best course of treatment."
            },
            "low": {
                "message": "Self-care may be appropriate",
                "actions": [
                    "Try recommended self-care measures",
                    "Monitor symptoms for 7-10 days",
                    "Seek care if symptoms worsen or persist"
                ],
                "disclaimer": "These symptoms often resolve with self-care, but professional evaluation is available if needed."
            }
        }
        
        return advice.get(urgency_level, advice["medium"])
