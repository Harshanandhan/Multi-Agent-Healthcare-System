"""
Base Agent Class for Multi-Agent System
Implements core agent functionality with communication protocols
"""

from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
from datetime import datetime
from enum import Enum
import json
import uuid
import structlog

logger = structlog.get_logger()


class MessageType(Enum):
    """Types of messages agents can exchange"""
    REQUEST = "request"
    RESPONSE = "response"
    BROADCAST = "broadcast"
    ERROR = "error"
    ACKNOWLEDGEMENT = "ack"


class AgentMessage:
    """Structured message format for agent communication"""
    
    def __init__(
        self,
        message_type: MessageType,
        sender_id: str,
        receiver_id: str,
        content: Dict[str, Any],
        conversation_id: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.message_id = str(uuid.uuid4())
        self.message_type = message_type
        self.sender_id = sender_id
        self.receiver_id = receiver_id
        self.content = content
        self.conversation_id = conversation_id or str(uuid.uuid4())
        self.timestamp = datetime.utcnow().isoformat()
        self.metadata = metadata or {}
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert message to dictionary for serialization"""
        return {
            "message_id": self.message_id,
            "message_type": self.message_type.value,
            "sender_id": self.sender_id,
            "receiver_id": self.receiver_id,
            "content": self.content,
            "conversation_id": self.conversation_id,
            "timestamp": self.timestamp,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AgentMessage':
        """Create message from dictionary"""
        msg = cls(
            message_type=MessageType(data["message_type"]),
            sender_id=data["sender_id"],
            receiver_id=data["receiver_id"],
            content=data["content"],
            conversation_id=data.get("conversation_id"),
            metadata=data.get("metadata")
        )
        msg.message_id = data["message_id"]
        msg.timestamp = data["timestamp"]
        return msg
    
    def to_json(self) -> str:
        """Convert message to JSON string"""
        return json.dumps(self.to_dict())
    
    @classmethod
    def from_json(cls, json_str: str) -> 'AgentMessage':
        """Create message from JSON string"""
        return cls.from_dict(json.loads(json_str))


class AgentCapability(Enum):
    """Capabilities that agents can have"""
    QUERY_PROCESSING = "query_processing"
    KNOWLEDGE_RETRIEVAL = "knowledge_retrieval"
    RESPONSE_GENERATION = "response_generation"
    TRIAGE = "triage"
    DECISION_MAKING = "decision_making"


class BaseAgent(ABC):
    """
    Abstract base class for all agents in the system.
    Provides common functionality for communication, logging, and state management.
    """
    
    def __init__(
        self,
        agent_id: str,
        name: str,
        capabilities: List[AgentCapability],
        description: str = ""
    ):
        self.agent_id = agent_id
        self.name = name
        self.capabilities = capabilities
        self.description = description
        self.state = {}
        self.message_queue = []
        self.logger = structlog.get_logger().bind(agent_id=agent_id, agent_name=name)
        self.conversation_history = {}
        self.performance_metrics = {
            "messages_sent": 0,
            "messages_received": 0,
            "tasks_completed": 0,
            "errors": 0
        }
    
    @abstractmethod
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """
        Process incoming message and return response if needed.
        Must be implemented by subclasses.
        """
        pass
    
    @abstractmethod
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a specific task assigned to this agent.
        Must be implemented by subclasses.
        """
        pass
    
    def send_message(
        self,
        receiver_id: str,
        content: Dict[str, Any],
        message_type: MessageType = MessageType.REQUEST,
        conversation_id: Optional[str] = None
    ) -> AgentMessage:
        """Create and send a message to another agent"""
        message = AgentMessage(
            message_type=message_type,
            sender_id=self.agent_id,
            receiver_id=receiver_id,
            content=content,
            conversation_id=conversation_id
        )
        
        self.performance_metrics["messages_sent"] += 1
        self.logger.info(
            "message_sent",
            receiver=receiver_id,
            message_type=message_type.value,
            conversation_id=conversation_id
        )
        
        return message
    
    def receive_message(self, message: AgentMessage) -> None:
        """Receive and queue a message"""
        self.message_queue.append(message)
        self.performance_metrics["messages_received"] += 1
        
        # Store in conversation history
        conv_id = message.conversation_id
        if conv_id not in self.conversation_history:
            self.conversation_history[conv_id] = []
        self.conversation_history[conv_id].append(message)
        
        self.logger.info(
            "message_received",
            sender=message.sender_id,
            message_type=message.message_type.value,
            conversation_id=conv_id
        )
    
    def get_conversation_context(self, conversation_id: str) -> List[AgentMessage]:
        """Retrieve conversation history for context"""
        return self.conversation_history.get(conversation_id, [])
    
    def update_state(self, key: str, value: Any) -> None:
        """Update agent's internal state"""
        self.state[key] = value
        self.logger.debug("state_updated", key=key)
    
    def get_state(self, key: str, default: Any = None) -> Any:
        """Retrieve value from agent's internal state"""
        return self.state.get(key, default)
    
    def has_capability(self, capability: AgentCapability) -> bool:
        """Check if agent has a specific capability"""
        return capability in self.capabilities
    
    def get_info(self) -> Dict[str, Any]:
        """Get agent information"""
        return {
            "agent_id": self.agent_id,
            "name": self.name,
            "capabilities": [cap.value for cap in self.capabilities],
            "description": self.description,
            "performance_metrics": self.performance_metrics,
            "active_conversations": len(self.conversation_history)
        }
    
    def log_error(self, error: Exception, context: Dict[str, Any] = None) -> None:
        """Log an error with context"""
        self.performance_metrics["errors"] += 1
        self.logger.error(
            "agent_error",
            error=str(error),
            error_type=type(error).__name__,
            context=context or {}
        )
