"""
Response Generation Agent - Generates natural language responses using LLM
"""

from typing import Dict, Any, Optional, List
from datetime import datetime
import json

from .base_agent import BaseAgent, AgentMessage, MessageType, AgentCapability


class ResponseAgent(BaseAgent):
    """
    Agent responsible for:
    1. Generating natural language responses
    2. Formatting medical information for users
    3. Ensuring appropriate disclaimers
    4. Personalizing based on user context
    """
    
    def __init__(self, llm_config: Optional[Dict[str, Any]] = None):
        super().__init__(
            agent_id="response_agent",
            name="Response Generation Agent",
            capabilities=[AgentCapability.RESPONSE_GENERATION],
            description="Generates user-friendly responses from medical knowledge"
        )
        
        self.llm_config = llm_config or {}
        self.response_templates = self._initialize_templates()
    
    def _initialize_templates(self) -> Dict[str, str]:
        """Initialize response templates for different scenarios"""
        return {
            "standard_response": """
Based on your symptoms, here's what I found:

{symptom_summary}

{condition_analysis}

{self_care_section}

{when_to_seek_care}

{disclaimer}
""",
            "emergency_response": """
⚠️ IMPORTANT: {emergency_message}

{immediate_actions}

{disclaimer}
""",
            "no_match_response": """
I've reviewed your symptoms, but I'm unable to provide a specific assessment.

{general_advice}

{recommendation}

{disclaimer}
"""
        }
    
    async def process_message(self, message: AgentMessage) -> Optional[AgentMessage]:
        """Process incoming message from knowledge agent"""
        try:
            if message.message_type == MessageType.REQUEST:
                # Generate response
                result = await self.execute_task(message.content)
                
                # Send back to user (via orchestrator)
                return self.send_message(
                    receiver_id="orchestrator",
                    content=result,
                    message_type=MessageType.RESPONSE,
                    conversation_id=message.conversation_id
                )
            
            return None
            
        except Exception as e:
            self.log_error(e, {"message_id": message.message_id})
            return self.send_message(
                receiver_id=message.sender_id,
                content={"error": str(e), "status": "failed"},
                message_type=MessageType.ERROR,
                conversation_id=message.conversation_id
            )
    
    async def execute_task(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute response generation:
        1. Analyze retrieved knowledge
        2. Format response appropriately
        3. Add disclaimers and safety information
        4. Personalize based on user context
        """
        urgency_level = task.get("urgency_level", "low")
        
        # Route to appropriate response generator
        if urgency_level == "emergency":
            response_text = self._generate_emergency_response(task)
        elif task.get("matched_conditions"):
            response_text = self._generate_standard_response(task)
        else:
            response_text = self._generate_no_match_response(task)
        
        # Add metadata for frontend rendering
        response_result = {
            **task,
            "response_text": response_text,
            "response_generated": True,
            "timestamp": datetime.utcnow().isoformat(),
            "status": "completed",
            "ui_elements": self._generate_ui_elements(task)
        }
        
        self.update_state("last_response", response_result)
        self.performance_metrics["tasks_completed"] += 1
        
        self.logger.info(
            "response_generated",
            urgency=urgency_level,
            response_length=len(response_text)
        )
        
        return response_result
    
    def _generate_standard_response(self, task: Dict[str, Any]) -> str:
        """Generate standard response for matched conditions"""
        # Extract information
        extracted_symptoms = task.get("extracted_symptoms", [])
        condition_details = task.get("condition_details", [])
        general_advice = task.get("general_advice", {})
        urgency_level = task.get("urgency_level", "low")
        
        # Build symptom summary
        symptom_summary = self._format_symptom_summary(extracted_symptoms)
        
        # Build condition analysis
        condition_analysis = self._format_condition_analysis(condition_details)
        
        # Build self-care section
        self_care_section = self._format_self_care(condition_details, urgency_level)
        
        # Build when to seek care section
        when_to_seek_care = self._format_when_to_seek_care(
            condition_details,
            general_advice
        )
        
        # Medical disclaimer
        disclaimer = self._get_medical_disclaimer()
        
        # Fill template
        response = self.response_templates["standard_response"].format(
            symptom_summary=symptom_summary,
            condition_analysis=condition_analysis,
            self_care_section=self_care_section,
            when_to_seek_care=when_to_seek_care,
            disclaimer=disclaimer
        )
        
        return response.strip()
    
    def _generate_emergency_response(self, task: Dict[str, Any]) -> str:
        """Generate emergency response"""
        general_advice = task.get("general_advice", {})
        
        emergency_message = general_advice.get(
            "message",
            "SEEK IMMEDIATE MEDICAL ATTENTION"
        )
        
        actions = general_advice.get("actions", [])
        immediate_actions = "\n".join([f"• {action}" for action in actions])
        
        disclaimer = self._get_medical_disclaimer()
        
        response = self.response_templates["emergency_response"].format(
            emergency_message=emergency_message,
            immediate_actions=immediate_actions,
            disclaimer=disclaimer
        )
        
        return response.strip()
    
    def _generate_no_match_response(self, task: Dict[str, Any]) -> str:
        """Generate response when no conditions matched"""
        general_advice = task.get("general_advice", {})
        
        advice_message = general_advice.get(
            "message",
            "Your symptoms don't closely match common conditions in our database."
        )
        
        recommendation = """
I recommend:
• Consulting with a healthcare provider for a proper evaluation
• Keeping track of your symptoms and any changes
• Seeking immediate care if symptoms worsen
"""
        
        disclaimer = self._get_medical_disclaimer()
        
        response = self.response_templates["no_match_response"].format(
            general_advice=advice_message,
            recommendation=recommendation,
            disclaimer=disclaimer
        )
        
        return response.strip()
    
    def _format_symptom_summary(self, symptoms: List[str]) -> str:
        """Format symptom summary"""
        if not symptoms:
            return "You haven't specified specific symptoms."
        
        symptom_list = ", ".join(symptoms)
        return f"You reported: {symptom_list}"
    
    def _format_condition_analysis(
        self,
        condition_details: List[Dict[str, Any]]
    ) -> str:
        """Format condition analysis section"""
        if not condition_details:
            return "I couldn't match your symptoms to specific conditions."
        
        sections = ["**Possible Conditions:**\n"]
        
        for i, condition in enumerate(condition_details, 1):
            name = condition.get("condition_name", "Unknown")
            confidence = condition.get("confidence", 0)
            duration = condition.get("typical_duration", "Variable")
            matching = ", ".join(condition.get("matching_symptoms", []))
            
            confidence_label = self._get_confidence_label(confidence)
            
            section = f"""
{i}. **{name}** ({confidence_label} match)
   - Matching symptoms: {matching}
   - Typical duration: {duration}
"""
            sections.append(section)
        
        return "\n".join(sections)
    
    def _format_self_care(
        self,
        condition_details: List[Dict[str, Any]],
        urgency_level: str
    ) -> str:
        """Format self-care recommendations"""
        if urgency_level in ["emergency", "high"]:
            return "**Immediate Care Required** - Please seek professional medical attention."
        
        if not condition_details:
            return ""
        
        sections = ["**Self-Care Recommendations:**\n"]
        
        # Collect all self-care tips
        all_tips = []
        for condition in condition_details:
            tips = condition.get("self_care", [])
            all_tips.extend(tips)
        
        # Remove duplicates while preserving order
        unique_tips = list(dict.fromkeys(all_tips))
        
        for tip in unique_tips[:6]:  # Limit to 6 tips
            sections.append(f"• {tip}")
        
        return "\n".join(sections)
    
    def _format_when_to_seek_care(
        self,
        condition_details: List[Dict[str, Any]],
        general_advice: Dict[str, Any]
    ) -> str:
        """Format when to seek care section"""
        sections = ["**When to Seek Medical Care:**\n"]
        
        # Add general advice
        actions = general_advice.get("actions", [])
        for action in actions:
            sections.append(f"• {action}")
        
        # Add condition-specific warnings
        if condition_details:
            sections.append("\n**Warning signs that require immediate attention:**")
            
            all_warnings = []
            for condition in condition_details:
                warnings = condition.get("when_to_seek_care", [])
                all_warnings.extend(warnings)
            
            unique_warnings = list(dict.fromkeys(all_warnings))
            for warning in unique_warnings[:5]:  # Limit to 5 warnings
                sections.append(f"• {warning}")
        
        return "\n".join(sections)
    
    def _get_confidence_label(self, confidence: float) -> str:
        """Convert confidence score to label"""
        if confidence >= 0.7:
            return "Strong"
        elif confidence >= 0.4:
            return "Moderate"
        else:
            return "Possible"
    
    def _get_medical_disclaimer(self) -> str:
        """Get standard medical disclaimer"""
        return """
---
**Important Disclaimer:**
This information is for educational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment. Always seek the advice of your physician or other qualified health provider with any questions you may have regarding a medical condition. Never disregard professional medical advice or delay in seeking it because of information provided here.

If you think you may have a medical emergency, call your doctor or 911 immediately.
"""
    
    def _generate_ui_elements(self, task: Dict[str, Any]) -> Dict[str, Any]:
        """Generate UI elements for frontend rendering"""
        urgency_level = task.get("urgency_level", "low")
        condition_details = task.get("condition_details", [])
        
        urgency_colors = {
            "emergency": "red",
            "high": "orange",
            "medium": "yellow",
            "low": "green"
        }
        
        return {
            "urgency_badge": {
                "level": urgency_level.upper(),
                "color": urgency_colors.get(urgency_level, "gray")
            },
            "condition_cards": [
                {
                    "name": cond.get("condition_name"),
                    "confidence": cond.get("confidence"),
                    "severity": cond.get("severity")
                }
                for cond in condition_details
            ],
            "show_emergency_banner": urgency_level == "emergency"
        }
