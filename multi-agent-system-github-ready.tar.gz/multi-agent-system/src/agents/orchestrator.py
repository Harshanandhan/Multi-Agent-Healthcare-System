"""
Agent Orchestrator - Manages multi-agent communication and workflow
"""

from typing import Dict, Any, List, Optional
import asyncio
from datetime import datetime
import uuid

from .base_agent import BaseAgent, AgentMessage, MessageType
from .triage_agent import TriageAgent
from .knowledge_agent import KnowledgeAgent
from .response_agent import ResponseAgent
import structlog

logger = structlog.get_logger()


class AgentOrchestrator:
    """
    Orchestrates communication between multiple agents.
    Manages message routing, state persistence, and workflow execution.
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        self.config = config or {}
        self.agents: Dict[str, BaseAgent] = {}
        self.message_bus: List[AgentMessage] = []
        self.active_conversations: Dict[str, Dict[str, Any]] = {}
        self.logger = structlog.get_logger().bind(component="orchestrator")
        
        # Performance tracking
        self.metrics = {
            "total_conversations": 0,
            "successful_completions": 0,
            "errors": 0,
            "average_response_time": 0
        }
        
        # Initialize agents
        self._initialize_agents()
    
    def _initialize_agents(self) -> None:
        """Initialize all agents in the system"""
        self.logger.info("initializing_agents")
        
        # Create agents
        triage_agent = TriageAgent()
        knowledge_agent = KnowledgeAgent()
        response_agent = ResponseAgent(self.config.get("llm_config"))
        
        # Register agents
        self.register_agent(triage_agent)
        self.register_agent(knowledge_agent)
        self.register_agent(response_agent)
        
        self.logger.info(
            "agents_initialized",
            num_agents=len(self.agents),
            agent_ids=list(self.agents.keys())
        )
    
    def register_agent(self, agent: BaseAgent) -> None:
        """Register an agent with the orchestrator"""
        self.agents[agent.agent_id] = agent
        self.logger.info("agent_registered", agent_id=agent.agent_id, agent_name=agent.name)
    
    def get_agent(self, agent_id: str) -> Optional[BaseAgent]:
        """Retrieve agent by ID"""
        return self.agents.get(agent_id)
    
    async def process_user_query(
        self,
        query: str,
        user_data: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """
        Process a user query through the multi-agent system.
        
        Workflow:
        1. User Query -> Triage Agent
        2. Triage Agent -> Knowledge Agent
        3. Knowledge Agent -> Response Agent
        4. Response Agent -> User (via orchestrator)
        """
        start_time = datetime.utcnow()
        conversation_id = str(uuid.uuid4())
        
        self.logger.info(
            "processing_user_query",
            conversation_id=conversation_id,
            query_length=len(query)
        )
        
        try:
            # Initialize conversation tracking
            self.active_conversations[conversation_id] = {
                "start_time": start_time,
                "query": query,
                "user_data": user_data or {},
                "messages": [],
                "status": "processing"
            }
            
            # Create initial message to triage agent
            initial_message = AgentMessage(
                message_type=MessageType.REQUEST,
                sender_id="user",
                receiver_id="triage_agent",
                content={
                    "query": query,
                    "user_data": user_data or {}
                },
                conversation_id=conversation_id
            )
            
            # Start the agent workflow
            result = await self._execute_workflow(initial_message)
            
            # Calculate response time
            end_time = datetime.utcnow()
            response_time = (end_time - start_time).total_seconds()
            
            # Update metrics
            self.metrics["total_conversations"] += 1
            self.metrics["successful_completions"] += 1
            self._update_average_response_time(response_time)
            
            # Update conversation status
            self.active_conversations[conversation_id]["status"] = "completed"
            self.active_conversations[conversation_id]["end_time"] = end_time
            self.active_conversations[conversation_id]["response_time"] = response_time
            
            self.logger.info(
                "query_processed_successfully",
                conversation_id=conversation_id,
                response_time=response_time
            )
            
            return result
            
        except Exception as e:
            self.metrics["errors"] += 1
            self.logger.error(
                "query_processing_failed",
                conversation_id=conversation_id,
                error=str(e)
            )
            
            # Update conversation status
            if conversation_id in self.active_conversations:
                self.active_conversations[conversation_id]["status"] = "failed"
                self.active_conversations[conversation_id]["error"] = str(e)
            
            return {
                "status": "error",
                "error": str(e),
                "conversation_id": conversation_id
            }
    
    async def _execute_workflow(self, initial_message: AgentMessage) -> Dict[str, Any]:
        """
        Execute the agent workflow by routing messages between agents.
        """
        conversation_id = initial_message.conversation_id
        current_message = initial_message
        
        # Track all messages in this conversation
        conversation_messages = []
        
        # Maximum iterations to prevent infinite loops
        max_iterations = 10
        iteration = 0
        
        while iteration < max_iterations:
            iteration += 1
            
            # Store message
            conversation_messages.append(current_message)
            self.active_conversations[conversation_id]["messages"].append(
                current_message.to_dict()
            )
            
            # Get the receiving agent
            receiver_id = current_message.receiver_id
            
            # Special handling for orchestrator (final response)
            if receiver_id == "orchestrator":
                self.logger.info(
                    "workflow_completed",
                    conversation_id=conversation_id,
                    iterations=iteration
                )
                return current_message.content
            
            # Get agent
            agent = self.get_agent(receiver_id)
            if not agent:
                raise ValueError(f"Agent not found: {receiver_id}")
            
            # Deliver message to agent
            agent.receive_message(current_message)
            
            # Process message
            self.logger.debug(
                "agent_processing",
                agent_id=agent.agent_id,
                message_type=current_message.message_type.value
            )
            
            response_message = await agent.process_message(current_message)
            
            if response_message is None:
                raise ValueError(f"Agent {receiver_id} returned no response")
            
            # Check for errors
            if response_message.message_type == MessageType.ERROR:
                raise ValueError(
                    f"Agent {receiver_id} returned error: {response_message.content}"
                )
            
            # Continue with next agent
            current_message = response_message
        
        raise RuntimeError(
            f"Workflow exceeded maximum iterations ({max_iterations})"
        )
    
    def _update_average_response_time(self, response_time: float) -> None:
        """Update average response time metric"""
        total = self.metrics["total_conversations"]
        current_avg = self.metrics["average_response_time"]
        
        # Calculate new average
        new_avg = ((current_avg * (total - 1)) + response_time) / total
        self.metrics["average_response_time"] = new_avg
    
    def get_conversation_log(self, conversation_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve complete conversation log"""
        return self.active_conversations.get(conversation_id)
    
    def get_all_conversations(self) -> List[Dict[str, Any]]:
        """Retrieve all conversation logs"""
        return [
            {
                "conversation_id": conv_id,
                **conv_data
            }
            for conv_id, conv_data in self.active_conversations.items()
        ]
    
    def get_agent_info(self, agent_id: str) -> Optional[Dict[str, Any]]:
        """Get information about a specific agent"""
        agent = self.get_agent(agent_id)
        if agent:
            return agent.get_info()
        return None
    
    def get_all_agent_info(self) -> List[Dict[str, Any]]:
        """Get information about all agents"""
        return [agent.get_info() for agent in self.agents.values()]
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get orchestrator metrics"""
        return {
            **self.metrics,
            "num_agents": len(self.agents),
            "active_conversations": len([
                c for c in self.active_conversations.values()
                if c["status"] == "processing"
            ])
        }
    
    def reset_metrics(self) -> None:
        """Reset performance metrics"""
        self.metrics = {
            "total_conversations": 0,
            "successful_completions": 0,
            "errors": 0,
            "average_response_time": 0
        }
        self.logger.info("metrics_reset")
    
    async def health_check(self) -> Dict[str, Any]:
        """Perform health check on all agents"""
        health_status = {
            "orchestrator": "healthy",
            "agents": {}
        }
        
        for agent_id, agent in self.agents.items():
            try:
                # Check if agent is responsive
                info = agent.get_info()
                health_status["agents"][agent_id] = {
                    "status": "healthy",
                    "info": info
                }
            except Exception as e:
                health_status["agents"][agent_id] = {
                    "status": "unhealthy",
                    "error": str(e)
                }
        
        return health_status
