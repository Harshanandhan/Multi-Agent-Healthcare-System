# Deployment Guide

## Deployment Options

### Option 1: Local Development

**Quick Start:**
```bash
# Clone repository
git clone https://github.com/yourusername/multi-agent-healthcare-system.git
cd multi-agent-healthcare-system

# Setup virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Run application
streamlit run app.py
```

### Option 2: Docker Deployment

**Prerequisites:**
- Docker installed
- Docker Compose installed

**Dockerfile:**
```dockerfile
FROM python:3.9-slim

WORKDIR /app

# Install system dependencies
RUN apt-get update && apt-get install -y \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# Copy requirements
COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

# Copy application
COPY . .

# Create necessary directories
RUN mkdir -p logs data/raw data/processed data/anonymized

# Expose port
EXPOSE 8501

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
  CMD curl -f http://localhost:8501/_stcore/health || exit 1

# Run application
CMD ["streamlit", "run", "app.py", "--server.address", "0.0.0.0"]
```

**docker-compose.yml:**
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8501:8501"
    environment:
      - ENVIRONMENT=production
      - USE_REDIS=true
      - REDIS_HOST=redis
    volumes:
      - ./logs:/app/logs
      - ./data:/app/data
    depends_on:
      - redis
    restart: unless-stopped
    networks:
      - app-network

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
    volumes:
      - redis-data:/data
    restart: unless-stopped
    networks:
      - app-network

volumes:
  redis-data:

networks:
  app-network:
    driver: bridge
```

**Build and Run:**
```bash
# Build images
docker-compose build

# Start services
docker-compose up -d

# View logs
docker-compose logs -f app

# Stop services
docker-compose down
```

### Option 3: Cloud Deployment (AWS)

**Architecture:**
```
Internet → Load Balancer → ECS/Fargate → Application
                              ↓
                          ElastiCache Redis
                              ↓
                          CloudWatch Logs
```

**AWS ECS Task Definition (example):**
```json
{
  "family": "healthcare-agent-system",
  "networkMode": "awsvpc",
  "requiresCompatibilities": ["FARGATE"],
  "cpu": "512",
  "memory": "1024",
  "containerDefinitions": [
    {
      "name": "app",
      "image": "your-registry/healthcare-agent-system:latest",
      "portMappings": [
        {
          "containerPort": 8501,
          "protocol": "tcp"
        }
      ],
      "environment": [
        {"name": "ENVIRONMENT", "value": "production"},
        {"name": "USE_REDIS", "value": "true"}
      ],
      "secrets": [
        {
          "name": "SECRET_KEY",
          "valueFrom": "arn:aws:secretsmanager:region:account:secret:name"
        }
      ],
      "logConfiguration": {
        "logDriver": "awslogs",
        "options": {
          "awslogs-group": "/ecs/healthcare-agent-system",
          "awslogs-region": "us-east-1",
          "awslogs-stream-prefix": "ecs"
        }
      }
    }
  ]
}
```

**Deployment Steps:**
1. Build and push Docker image to ECR
2. Create ECS cluster
3. Configure task definition
4. Create service with load balancer
5. Configure ElastiCache for Redis
6. Set up CloudWatch monitoring

### Option 4: Heroku Deployment

**Prerequisites:**
- Heroku CLI installed
- Heroku account

**Procfile:**
```
web: streamlit run app.py --server.port=$PORT --server.address=0.0.0.0
```

**runtime.txt:**
```
python-3.9.16
```

**Deploy:**
```bash
# Login to Heroku
heroku login

# Create app
heroku create your-app-name

# Add Redis addon
heroku addons:create heroku-redis:hobby-dev

# Set environment variables
heroku config:set ENVIRONMENT=production
heroku config:set USE_REDIS=true

# Deploy
git push heroku main

# Open app
heroku open
```

### Option 5: Kubernetes Deployment

**k8s/deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: healthcare-agent-system
  labels:
    app: healthcare-agent
spec:
  replicas: 3
  selector:
    matchLabels:
      app: healthcare-agent
  template:
    metadata:
      labels:
        app: healthcare-agent
    spec:
      containers:
      - name: app
        image: your-registry/healthcare-agent-system:latest
        ports:
        - containerPort: 8501
        env:
        - name: ENVIRONMENT
          value: "production"
        - name: REDIS_HOST
          value: "redis-service"
        resources:
          requests:
            memory: "512Mi"
            cpu: "250m"
          limits:
            memory: "1Gi"
            cpu: "500m"
        livenessProbe:
          httpGet:
            path: /_stcore/health
            port: 8501
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /_stcore/health
            port: 8501
          initialDelaySeconds: 5
          periodSeconds: 5
---
apiVersion: v1
kind: Service
metadata:
  name: healthcare-agent-service
spec:
  selector:
    app: healthcare-agent
  ports:
  - protocol: TCP
    port: 80
    targetPort: 8501
  type: LoadBalancer
```

**Deploy to Kubernetes:**
```bash
# Apply deployment
kubectl apply -f k8s/deployment.yaml

# Check status
kubectl get pods
kubectl get services

# View logs
kubectl logs -l app=healthcare-agent
```

## Configuration Management

### Environment Variables

**Production Settings:**
```bash
# Required
export ENVIRONMENT=production
export SECRET_KEY=$(openssl rand -hex 32)

# Optional but recommended
export USE_REDIS=true
export REDIS_HOST=your-redis-host
export ENABLE_ENCRYPTION=true

# Monitoring
export ENABLE_METRICS=true
export LOG_LEVEL=WARNING
```

### Secrets Management

**Using AWS Secrets Manager:**
```python
import boto3
import json

def get_secret(secret_name):
    client = boto3.client('secretsmanager', region_name='us-east-1')
    response = client.get_secret_value(SecretId=secret_name)
    return json.loads(response['SecretString'])

# Use in application
secrets = get_secret('healthcare-agent-system/prod')
config.SECRET_KEY = secrets['secret_key']
```

## Monitoring & Logging

### Application Metrics

**Prometheus Integration:**
```python
from prometheus_client import Counter, Histogram, start_http_server

# Define metrics
conversation_counter = Counter('conversations_total', 'Total conversations')
response_time = Histogram('response_time_seconds', 'Response time')

# Start metrics server
start_http_server(9090)
```

**Grafana Dashboard:**
- Response times
- Error rates
- Agent activity
- Fairness metrics
- Privacy events

### Logging

**Structured Logging:**
```python
import structlog

logger = structlog.get_logger()
logger.info("conversation_started", conversation_id=conv_id, urgency=urgency)
```

**Log Aggregation:**
- CloudWatch Logs (AWS)
- Stackdriver (GCP)
- ELK Stack (self-hosted)

## Security Considerations

### Production Checklist

- [ ] Change default SECRET_KEY
- [ ] Enable HTTPS/TLS
- [ ] Configure firewall rules
- [ ] Enable encryption at rest
- [ ] Set up rate limiting
- [ ] Configure CORS properly
- [ ] Enable audit logging
- [ ] Regular security updates
- [ ] Backup strategy in place
- [ ] Disaster recovery plan

### HTTPS Setup (Nginx)

**nginx.conf:**
```nginx
server {
    listen 443 ssl http2;
    server_name your-domain.com;

    ssl_certificate /etc/ssl/certs/cert.pem;
    ssl_certificate_key /etc/ssl/private/key.pem;

    location / {
        proxy_pass http://localhost:8501;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}

server {
    listen 80;
    server_name your-domain.com;
    return 301 https://$server_name$request_uri;
}
```

## Performance Optimization

### Caching Strategy

**Redis Caching:**
```python
import redis
import json

cache = redis.Redis(host='localhost', port=6379, db=0)

def get_cached_response(query_hash):
    cached = cache.get(query_hash)
    return json.loads(cached) if cached else None

def cache_response(query_hash, response, ttl=3600):
    cache.setex(query_hash, ttl, json.dumps(response))
```

### Load Balancing

**Nginx Load Balancer:**
```nginx
upstream healthcare_agents {
    least_conn;
    server app1:8501;
    server app2:8501;
    server app3:8501;
}

server {
    listen 80;
    location / {
        proxy_pass http://healthcare_agents;
    }
}
```

## Scaling Strategies

### Horizontal Scaling
- Multiple application instances
- Load balancer distribution
- Shared Redis for state
- Distributed logging

### Vertical Scaling
- Increase CPU/memory
- Optimize agent algorithms
- Database query optimization
- Caching implementation

## Backup & Recovery

### Data Backup

**Automated Backup Script:**
```bash
#!/bin/bash
# backup.sh

BACKUP_DIR="/backups/$(date +%Y%m%d)"
mkdir -p $BACKUP_DIR

# Backup logs
tar -czf $BACKUP_DIR/logs.tar.gz logs/

# Backup data
tar -czf $BACKUP_DIR/data.tar.gz data/

# Backup configuration
cp .env $BACKUP_DIR/

# Upload to S3
aws s3 cp $BACKUP_DIR s3://your-bucket/backups/ --recursive
```

### Disaster Recovery

1. **Daily Backups**: Automated backup to S3/cloud storage
2. **Replication**: Multi-region deployment
3. **Monitoring**: Alert on failures
4. **Recovery Plan**: Documented recovery procedures

## Maintenance

### Update Procedure

```bash
# 1. Backup current version
./backup.sh

# 2. Pull latest changes
git pull origin main

# 3. Update dependencies
pip install -r requirements.txt --upgrade

# 4. Run migrations (if any)
python manage.py migrate

# 5. Restart application
docker-compose restart app

# 6. Verify deployment
./health_check.sh
```

### Health Checks

```bash
#!/bin/bash
# health_check.sh

ENDPOINT="http://localhost:8501/_stcore/health"

response=$(curl -s -o /dev/null -w "%{http_code}" $ENDPOINT)

if [ $response -eq 200 ]; then
    echo "✓ Application is healthy"
    exit 0
else
    echo "✗ Application is unhealthy (HTTP $response)"
    exit 1
fi
```

## Cost Optimization

### Resource Sizing

**Small Deployment** (Development/Testing):
- 1 CPU, 1GB RAM
- No Redis
- Local storage
- Cost: ~$5-10/month

**Medium Deployment** (Small Production):
- 2 CPUs, 2GB RAM
- Managed Redis
- Cloud storage
- Cost: ~$50-100/month

**Large Deployment** (Production):
- 4+ CPUs, 4GB+ RAM
- Redis cluster
- CDN, Load balancer
- Cost: ~$200-500/month

## Support & Troubleshooting

### Common Issues

1. **Application won't start**
   - Check logs: `docker-compose logs app`
   - Verify environment variables
   - Check port availability

2. **Slow responses**
   - Enable Redis caching
   - Scale horizontally
   - Optimize agent algorithms

3. **Memory issues**
   - Increase container memory
   - Implement garbage collection
   - Reduce conversation history

### Getting Help

- GitHub Issues: Report bugs
- Documentation: Check docs/
- Community: Discord/Slack channel
