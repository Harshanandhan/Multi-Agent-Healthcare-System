"""
Configuration settings for Multi-Agent Healthcare System
"""

import os
from typing import Dict, Any
from dotenv import load_dotenv

load_dotenv()


class Config:
    """Base configuration"""
    
    # Application settings
    APP_NAME = "HealthAssist AI"
    APP_VERSION = "1.0.0"
    DEBUG = os.getenv("DEBUG", "False").lower() == "true"
    
    # Agent configuration
    AGENT_TIMEOUT = int(os.getenv("AGENT_TIMEOUT", "30"))  # seconds
    MAX_AGENT_RETRIES = int(os.getenv("MAX_AGENT_RETRIES", "3"))
    
    # LLM settings (for future API integration)
    LLM_PROVIDER = os.getenv("LLM_PROVIDER", "openai")
    LLM_MODEL = os.getenv("LLM_MODEL", "gpt-4")
    LLM_TEMPERATURE = float(os.getenv("LLM_TEMPERATURE", "0.7"))
    LLM_MAX_TOKENS = int(os.getenv("LLM_MAX_TOKENS", "1000"))
    OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
    ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY", "")
    
    # State management
    USE_REDIS = os.getenv("USE_REDIS", "False").lower() == "true"
    REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
    REDIS_PORT = int(os.getenv("REDIS_PORT", "6379"))
    REDIS_DB = int(os.getenv("REDIS_DB", "0"))
    REDIS_PASSWORD = os.getenv("REDIS_PASSWORD", "")
    
    # Privacy settings
    ENABLE_PII_DETECTION = os.getenv("ENABLE_PII_DETECTION", "True").lower() == "true"
    ENABLE_ANONYMIZATION = os.getenv("ENABLE_ANONYMIZATION", "True").lower() == "true"
    ANONYMIZATION_METHOD = os.getenv("ANONYMIZATION_METHOD", "redaction")  # redaction, pseudonymization, hashing
    
    # GDPR compliance
    ENABLE_GDPR_LOGGING = os.getenv("ENABLE_GDPR_LOGGING", "True").lower() == "true"
    GDPR_LOG_FILE = os.getenv("GDPR_LOG_FILE", "logs/gdpr_compliance.jsonl")
    DATA_RETENTION_DAYS = int(os.getenv("DATA_RETENTION_DAYS", "90"))
    
    # Ethics & fairness
    ENABLE_BIAS_DETECTION = os.getenv("ENABLE_BIAS_DETECTION", "True").lower() == "true"
    FAIRNESS_THRESHOLD = float(os.getenv("FAIRNESS_THRESHOLD", "0.1"))
    ENABLE_ETHICS_MONITORING = os.getenv("ENABLE_ETHICS_MONITORING", "True").lower() == "true"
    
    # Logging
    LOG_LEVEL = os.getenv("LOG_LEVEL", "INFO")
    LOG_FILE = os.getenv("LOG_FILE", "logs/application.log")
    LOG_FORMAT = "%(timestamp)s %(level)s %(component)s %(message)s"
    
    # Performance
    ENABLE_METRICS = os.getenv("ENABLE_METRICS", "True").lower() == "true"
    METRICS_PORT = int(os.getenv("METRICS_PORT", "9090"))
    
    # Security
    ENABLE_ENCRYPTION = os.getenv("ENABLE_ENCRYPTION", "False").lower() == "true"
    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-in-production")
    
    # UI settings
    UI_THEME = os.getenv("UI_THEME", "light")
    MAX_CONVERSATION_HISTORY = int(os.getenv("MAX_CONVERSATION_HISTORY", "50"))
    
    @classmethod
    def to_dict(cls) -> Dict[str, Any]:
        """Convert config to dictionary"""
        return {
            key: value for key, value in cls.__dict__.items()
            if not key.startswith('_') and not callable(value)
        }
    
    @classmethod
    def validate(cls) -> bool:
        """Validate configuration"""
        errors = []
        
        # Check required settings
        if cls.USE_REDIS and not cls.REDIS_HOST:
            errors.append("REDIS_HOST is required when USE_REDIS is True")
        
        if cls.LLM_PROVIDER == "openai" and not cls.OPENAI_API_KEY:
            errors.append("OPENAI_API_KEY is required when using OpenAI")
        
        if cls.LLM_PROVIDER == "anthropic" and not cls.ANTHROPIC_API_KEY:
            errors.append("ANTHROPIC_API_KEY is required when using Anthropic")
        
        # Log errors
        if errors:
            for error in errors:
                print(f"Configuration Error: {error}")
            return False
        
        return True


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    LOG_LEVEL = "DEBUG"


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    LOG_LEVEL = "WARNING"
    ENABLE_ENCRYPTION = True


class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    USE_REDIS = False
    ENABLE_GDPR_LOGGING = False
    LOG_LEVEL = "DEBUG"


# Select configuration based on environment
ENV = os.getenv("ENVIRONMENT", "development").lower()

if ENV == "production":
    config = ProductionConfig
elif ENV == "testing":
    config = TestingConfig
else:
    config = DevelopmentConfig


# Validate configuration on import
if not config.validate():
    print("Warning: Configuration validation failed")
