# Contributing to Multi-Agent Healthcare System

Thank you for your interest in contributing to this project! This document provides guidelines for contributing.

## 🎯 Project Goals

This is primarily an **educational and portfolio project** demonstrating:
- Multi-agent AI systems
- Ethical AI practices
- Privacy-preserving technology
- Production-ready code

## 🤝 How to Contribute

### Reporting Bugs

If you find a bug, please create an issue with:
- Clear description of the problem
- Steps to reproduce
- Expected vs actual behavior
- Your environment (OS, Python version)
- Screenshots if applicable

### Suggesting Enhancements

For feature requests:
- Explain the use case
- Describe the proposed solution
- Consider alternatives
- Explain why this would be useful

### Pull Requests

1. **Fork the repository**
2. **Create a feature branch**
   ```bash
   git checkout -b feature/your-feature-name
   ```

3. **Make your changes**
   - Follow the existing code style
   - Add tests for new features
   - Update documentation

4. **Run tests**
   ```bash
   pytest tests/ -v
   ```

5. **Commit your changes**
   ```bash
   git commit -m "feat: add new feature"
   ```
   
   Use conventional commits:
   - `feat:` - New feature
   - `fix:` - Bug fix
   - `docs:` - Documentation changes
   - `test:` - Test additions/changes
   - `refactor:` - Code refactoring
   - `style:` - Formatting changes
   - `chore:` - Maintenance tasks

6. **Push to your fork**
   ```bash
   git push origin feature/your-feature-name
   ```

7. **Create a Pull Request**
   - Describe your changes
   - Reference any related issues
   - Explain testing performed

## 💻 Development Setup

```bash
# Clone your fork
git clone https://github.com/your-username/multi-agent-healthcare-system.git
cd multi-agent-healthcare-system

# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Install development dependencies
pip install pytest pytest-asyncio pytest-cov black flake8 mypy

# Run tests
pytest tests/ -v

# Run with coverage
pytest tests/ --cov=src --cov-report=html
```

## 📝 Code Style

### Python Style Guide
- Follow PEP 8
- Use type hints
- Write docstrings for functions and classes
- Keep functions focused and small

### Example:
```python
def process_symptom(symptom: str, urgency: str) -> Dict[str, Any]:
    """
    Process a symptom and determine appropriate action.
    
    Args:
        symptom: The symptom description
        urgency: Urgency level (low, medium, high, emergency)
    
    Returns:
        Dict containing processing results
    """
    # Implementation
    pass
```

### Code Formatting
We use `black` for formatting:
```bash
black src/ tests/
```

### Linting
```bash
flake8 src/ tests/
mypy src/
```

## 🧪 Testing Guidelines

### Writing Tests
- Write tests for new features
- Maintain high test coverage (>80%)
- Use descriptive test names
- Test edge cases

### Test Structure
```python
def test_feature_name_should_do_something():
    """Test that feature behaves correctly"""
    # Arrange
    agent = TriageAgent()
    
    # Act
    result = agent.process(input_data)
    
    # Assert
    assert result["status"] == "success"
```

### Running Specific Tests
```bash
# Run specific test file
pytest tests/test_agents.py -v

# Run specific test
pytest tests/test_agents.py::test_triage_agent -v

# Run with markers
pytest -m "not slow" -v
```

## 📚 Documentation

When adding features, update:
- Code docstrings
- README.md (if needed)
- CHANGELOG.md
- Inline comments for complex logic

## 🔒 Privacy & Ethics

When contributing, ensure:
- No PII in code or tests
- Privacy features are maintained
- Fairness considerations are addressed
- Medical disclaimers are preserved

## ⚠️ Medical Content

**Important:** This is an educational project.
- Do not add unverified medical information
- Keep medical disclaimers prominent
- Flag anything that could be misused
- Prioritize user safety

## 🎨 Areas for Contribution

### Easy (Good First Issues)
- Documentation improvements
- Adding unit tests
- Code formatting
- Bug fixes
- UI enhancements

### Moderate
- Adding new symptoms/conditions to knowledge base
- Implementing additional fairness metrics
- Enhancing privacy features
- Performance optimizations

### Advanced
- Integration with medical databases
- Multi-language support
- Voice interface
- Advanced LLM integration
- Kubernetes deployment configs

## 📋 Pull Request Checklist

Before submitting:
- [ ] Code follows project style guide
- [ ] Tests added/updated and passing
- [ ] Documentation updated
- [ ] No breaking changes (or clearly documented)
- [ ] Commits follow conventional commit format
- [ ] No sensitive data in commits
- [ ] Medical disclaimers preserved

## 🐛 Issue Labels

We use these labels:
- `bug` - Something isn't working
- `enhancement` - New feature or request
- `documentation` - Documentation improvements
- `good first issue` - Good for newcomers
- `help wanted` - Extra attention needed
- `question` - Further information requested
- `wontfix` - This will not be worked on
- `duplicate` - This issue already exists

## 💬 Communication

- Be respectful and constructive
- Ask questions if unclear
- Provide context and examples
- Be patient with maintainers

## 📜 Code of Conduct

### Our Standards

- Be welcoming and inclusive
- Respect differing viewpoints
- Accept constructive criticism gracefully
- Focus on what's best for the community
- Show empathy towards others

### Unacceptable Behavior

- Harassment or discriminatory language
- Trolling or insulting comments
- Personal or political attacks
- Publishing others' private information
- Unprofessional conduct

## 🙏 Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Mentioned in release notes
- Credited in documentation

## 📞 Getting Help

- Check existing issues
- Review documentation
- Ask in discussions
- Create a new issue

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

---

Thank you for contributing to the Multi-Agent Healthcare System! 🎉
